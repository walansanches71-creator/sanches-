chrome.action.onClicked.addListener(()=>chrome.windows.create({url:chrome.runtime.getURL('setor.html'),type:'popup',width:1180,height:850}));
importScripts("sector-background.js");
