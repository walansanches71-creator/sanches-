
/* ============================================================
   ARMAZENAMENTO LOCAL DA New Print Midia
   - Não usa chrome.storage.local para os dados grandes.
   - Usa IndexedDB (sem a cota de 10 MB do chrome.storage.local).
   - Pode espelhar automaticamente tudo em:
       C:\ProducaoVIP\producao-vip-dados.json
     O usuário escolhe a pasta uma única vez pelo botão
     "PASTA DE DADOS".
   ============================================================ */
const PVStorage = (() => {
  const DB_NAME = "producao-vip-db";
  const DB_VERSION = 2;
  const STORE = "kv";
  const FILE_NAME = "producao-vip-dados.json";
  let db = null;
  let data = {};
  let dirHandle = null;
  let readyResolve;
  const ready = new Promise(r => readyResolve = r);
  let writeChain = Promise.resolve();

  function openDB(){
    return new Promise((resolve,reject)=>{
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE);
        if (!d.objectStoreNames.contains("meta")) d.createObjectStore("meta");
      };
      req.onsuccess = () => { db=req.result; resolve(db); };
      req.onerror = () => reject(req.error);
    });
  }
  function idbGetAll(){
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readonly"), st=tx.objectStore(STORE), out={};
      const req=st.openCursor();
      req.onsuccess=()=>{
        const c=req.result;
        if(!c){resolve(out);return}
        out[c.key]=c.value;c.continue();
      };
      req.onerror=()=>reject(req.error);
    });
  }
  function idbPut(key,value){
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readwrite");
      tx.objectStore(STORE).put(value,key);
      tx.oncomplete=()=>resolve();
      tx.onerror=()=>reject(tx.error);
    });
  }
  function idbPutMany(obj){
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readwrite"), st=tx.objectStore(STORE);
      Object.entries(obj).forEach(([k,v])=>st.put(v,k));
      tx.oncomplete=()=>resolve();
      tx.onerror=()=>reject(tx.error);
    });
  }


  /* ESPELHO PARA O BACKGROUND (alertas de atraso)
     O service worker (background.js) só enxerga chrome.storage.local, e os pedidos
     ficam no IndexedDB. Aqui gravamos uma cópia ENXUTA (sem imagens/anexos) só com
     o que o alerta precisa, sem estourar a cota de 10 MB. */
  const CAMPOS_ALERTA=["id","cliente","pedido","os","prazo","horaMarcada","status","telefone","prioridade"];
  let ultimoEspelhoPedidos="";
  function pedidosEnxutos(lista){
    return (Array.isArray(lista)?lista:[]).map(p=>{const o={};CAMPOS_ALERTA.forEach(k=>{if(p&&p[k]!==undefined)o[k]=p[k]});return o});
  }
  async function espelharParaBackground(items){
    try{
      if(typeof chrome==="undefined"||!chrome.storage?.local)return;
      const out={};
      if(items&&"pedidos" in items){
        const enx=pedidosEnxutos(items.pedidos), json=JSON.stringify(enx);
        if(json!==ultimoEspelhoPedidos){ultimoEspelhoPedidos=json;out.pedidos=enx}
      }
      if(items&&"vozConfig" in items)out.vozConfig=items.vozConfig||{};
      if(Object.keys(out).length)await chrome.storage.local.set(out);
    }catch(e){console.warn("New Print Midia: não foi possível espelhar para o alerta de fundo:",e)}
  }

  async function readFileIfGranted(){
    if(!dirHandle || !dirHandle.queryPermission) return false;
    try{
      const perm=await dirHandle.queryPermission({mode:"readwrite"});
      if(perm!=="granted") return false;
      const fh=await dirHandle.getFileHandle(FILE_NAME,{create:false});
      const txt=await (await fh.getFile()).text();
      const obj=JSON.parse(txt);
      if(obj && typeof obj==="object" && !Array.isArray(obj)){
        data=obj;
        await idbPutMany(data);
        return true;
      }
    }catch(_){}
    return false;
  }

  async function writeFile(){
    if(!dirHandle) return;
    writeChain=writeChain.then(async()=>{
      try{
        const perm=await dirHandle.queryPermission({mode:"readwrite"});
        if(perm!=="granted") return;
        const fh=await dirHandle.getFileHandle(FILE_NAME,{create:true});
        const ws=await fh.createWritable();
        await ws.write(JSON.stringify(data,null,2));
        await ws.close();
      }catch(e){
        console.warn("New Print Midia: não foi possível gravar o arquivo:",e);
      }
    });
    return writeChain;
  }

  async function init(){
    try{
      await openDB();
      data=await idbGetAll();
      const h=await new Promise(resolve=>{
        try{
          const tx=db.transaction("meta","readonly");
          const r=tx.objectStore("meta").get("dirHandle");
          r.onsuccess=()=>resolve(r.result||null);
          r.onerror=()=>resolve(null);
        }catch(_){resolve(null)}
      });
      dirHandle=h;
      await readFileIfGranted();
      await espelharParaBackground({pedidos:data.pedidos||[],...(data.vozConfig?{vozConfig:data.vozConfig}:{})});
    }catch(e){
      console.warn("New Print Midia: IndexedDB indisponível.",e);
    }
    readyResolve();
  }

  async function saveHandle(h){
    await new Promise((resolve,reject)=>{
      const tx=db.transaction("meta","readwrite");
      tx.objectStore("meta").put(h,"dirHandle");
      tx.oncomplete=resolve;
      tx.onerror=()=>reject(tx.error);
    });
  }

  async function chooseFolder(){
    await ready;
    if(!window.showDirectoryPicker){
      alert("Seu Chrome não suporta seleção de pasta neste modo.");
      return false;
    }
    try{
      const picked=await window.showDirectoryPicker({mode:"readwrite"});
      // O usuário pode selecionar C:\ diretamente ou uma pasta como C:\ProducaoVIP.
      dirHandle=picked;
      if(dirHandle.requestPermission){
        const p=await dirHandle.requestPermission({mode:"readwrite"});
        if(p!=="granted") throw new Error("Permissão negada");
      }
      await saveHandle(dirHandle);
      await writeFile();
      updateFolderUI();
      alert("Pasta de dados configurada.\n\nOs dados agora serão salvos também no arquivo:\n"+FILE_NAME);
      return true;
    }catch(e){
      if(e?.name!=="AbortError") alert("Não foi possível configurar a pasta: "+(e?.message||e));
      return false;
    }
  }

  function updateFolderUI(){
    const el=document.getElementById("pvPastaStatus");
    if(el) el.textContent=dirHandle ? "🟢 Pasta de dados configurada" : "🟡 Selecione uma pasta para salvar no C:";
  }

  async function get(keys, cb){
    await ready;
    let out={};
    if(keys===null){
      out={...data};
    }else if(typeof keys==="string"){
      out[keys]=data[keys];
    }else{
      for(const [k,def] of Object.entries(keys||{})) out[k]=(k in data)?data[k]:def;
    }
    if(typeof cb==="function"){cb(out);return}
    return out;
  }

  async function set(items, cb, origin="local"){
    await ready;
    Object.assign(data,items||{});
    try{await idbPutMany(items||{});await writeFile();}
    catch(e){console.error("New Print Midia: erro ao salvar",e)}
    await espelharParaBackground(items);
    if(origin==="local" && items && (items.pedidos||items.lixeira||items.arquivados))window.dispatchEvent(new CustomEvent("pv-local-write",{detail:structuredClone(items)}));
    if(typeof cb==="function")cb();
  }

  async function remove(keys,cb){
    await ready;
    const arr=Array.isArray(keys)?keys:[keys];
    await new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readwrite"), st=tx.objectStore(STORE);
      arr.forEach(k=>{delete data[k];st.delete(k)});
      tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);
    });
    await writeFile();
    if(typeof cb==="function")cb();
  }

  init();
  async function savePricesToFolder(){await ready;if(!dirHandle)return false;try{if(await dirHandle.queryPermission({mode:'readwrite'})!=='granted')return false;await writeChain;const fh=await dirHandle.getFileHandle(FILE_NAME,{create:true}),ws=await fh.createWritable();await ws.write(JSON.stringify(data,null,2));await ws.close();return true}catch{return false}}
  return {get,set,remove,chooseFolder,updateFolderUI,savePricesToFolder};
})();

const $=s=>document.querySelector(s);
let pedidos=[];
const STATUS={producao:"EM PRODUÇÃO",impressao:"NA IMPRESSÃO",acabamento:"NO ACABAMENTO",corte:"EM CORTE",laser:"NO CORTE A LASER",costura:"NA COSTURA",estamparia:"NA ESTAMPARIA",calandra:"NA CALANDRA",material:"AGUARDANDO MATERIAL",pronto:"PRONTO",entregue:"ENTREGUE",cancelado:"CANCELADO"};
const STATUS_PRODUCAO=new Set(["producao","impressao","acabamento","corte","laser","costura","estamparia","calandra"]);
function usuarioAtual(){return {nome:String(window.__pvUsuarioNome||"").trim(),funcao:String(window.__pvUsuarioFuncao||"").trim()}}
function autorNota(){const u=usuarioAtual();return u.nome?(u.funcao?`${u.nome} — ${u.funcao}`:u.nome):"Usuário não configurado"}
function eventoHistorico(acao,extra={}){return {t:Date.now(),acao,responsavel:autorNota(),usuarioNome:usuarioAtual().nome,usuarioFuncao:usuarioAtual().funcao,...extra}}

const ITEM_TIPOS=["Camisas","Camisas — Bordado","Camisas — DTF Têxtil","Camisas — Sublimação Local","Bolsas","Mousepad","Fachada","Windbanner","Bandeira","Copos","Adesivos","Aplicação de adesivo","Lona","Banner","Cartão de visita","Flyer / Panfleto","Placas","Comunicação visual","DTF / DTF UV","Caneca","Brinde personalizado","Outro"];

function init(){
 PVStorage.get({pedidos:[],empresa:{nome:"New Print Midia",logo:""},usuario:{nome:"",funcao:""},lixeira:[],arquivados:[]},x=>{pedidos=x.pedidos||[];window.__pvUsuarioNome=(x.usuario||{}).nome||"";window.__pvUsuarioFuncao=(x.usuario||{}).funcao||"";aplicarEmpresa(x.empresa||{});render();autoBackupSemanal()});
 $("#entrada").value=new Date().toISOString().slice(0,10);
 $("#abrirForm").addEventListener("click",()=>{limpar();$("#form").classList.remove("oculto");$("#cliente").focus();$("#form").scrollIntoView({behavior:"smooth",block:"start"})});
 $("#cancelar").addEventListener("click",()=>{$("#form").classList.add("oculto")});
 $("#salvar").addEventListener("click",salvar);
 $("#adicionarItem").addEventListener("click",()=>adicionarItemForm());
 $("#busca").addEventListener("input",render);$("#filtro").addEventListener("change",render);$("#pesquisarDemanda").addEventListener("click",()=>{$("#busca").focus();render()});
 $("#fechar").addEventListener("click",()=>window.close());$("#min").addEventListener("click",()=>document.body.classList.toggle("minimizado"));
 $("#config").addEventListener("click",abrirConfig);$("#abrirConfig").addEventListener("dblclick",abrirConfig);$("#fecharConfig").addEventListener("click",fecharConfig);$("#salvarConfig").addEventListener("click",salvarConfig);
 $("#removerLogo").addEventListener("click",()=>{$("#empresaLogo").value="";mostrarPreview("");$("#configModal").dataset.logo=""});
 iniciarVoz();
 if($('#abrirCalendario'))$('#abrirCalendario').addEventListener('click',abrirCalendario);
 if($('#abrirPendencias'))$('#abrirPendencias').addEventListener('click',abrirPendencias);
 if($('#fecharPendencias'))$('#fecharPendencias').addEventListener('click',fecharPendencias);
 if($('#fecharPendenciaEditor'))$('#fecharPendenciaEditor').addEventListener('click',fecharEditorPendencia);
 if($('#cancelarPendencia'))$('#cancelarPendencia').addEventListener('click',fecharEditorPendencia);
 if($('#pendenciaForm'))$('#pendenciaForm').addEventListener('submit',salvarPendencia);
 document.querySelectorAll('.pend-tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.pend-tab').forEach(x=>x.classList.remove('ativo'));b.classList.add('ativo');renderPendencias(b.dataset.pf)}));
 if($('#fecharCalendario'))$('#fecharCalendario').addEventListener('click',fecharCalendario);
 if($('#calAnterior'))$('#calAnterior').addEventListener('click',()=>moverCalendario(-1));
 if($('#calProximo'))$('#calProximo').addEventListener('click',()=>moverCalendario(1));
 if($('#calHoje'))$('#calHoje').addEventListener('click',()=>{calData=new Date();calSelecionado=dataKey(new Date());renderCalendario()});
 if($('#calSetor'))$('#calSetor').addEventListener('change',renderCalendario);
 if($('#fecharCalDetalhe'))$('#fecharCalDetalhe').addEventListener('click',fecharCalDetalhe);
 if($('#calDetalheFechar'))$('#calDetalheFechar').addEventListener('click',fecharCalDetalhe);
 if($('#calDetalheEditar'))$('#calDetalheEditar').addEventListener('click',()=>{const id=$('#calDetalheModal')?.dataset.id;if(id){fecharCalDetalhe();fecharCalendario();abrirEdicao(id)}});
 $("#empresaLogo").addEventListener("change",previewLogo);$("#imagemPedido").addEventListener("change",previewImagemPedido);$("#removerImagemPedido").addEventListener("click",removerImagemPedido);$("#documentoOS").addEventListener("change",previewDocumentoOS);$("#removerDocumentoOS").addEventListener("click",removerDocumentoOS);$("#retirada").addEventListener("change",atualizarEndereco);
 $("#gerarPdfGeral").addEventListener("click",()=>gerarPdfGeral());
 $("#abrirModoTv").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"ABRIR_MODO_TV"}).catch(()=>{})});
 $("#abrirLixeira").addEventListener("click",abrirLixeira);
 $("#abrirRelatorio").addEventListener("click",abrirRelatorio);
 $("#fecharRelatorio").addEventListener("click",()=>$("#relatorioModal").classList.add("oculto"));
 $("#relatorioGeral").addEventListener("click",()=>{document.querySelectorAll(".rel-tab").forEach(b=>b.classList.remove("ativo"));$("#relatorioGeral").classList.add("ativo");renderRelatorio("geral")});
 $("#relatorioPrioridades").addEventListener("click",()=>{document.querySelectorAll(".rel-tab").forEach(b=>b.classList.remove("ativo"));$("#relatorioPrioridades").classList.add("ativo");renderRelatorio("prioridades")});
 $("#exportarRelatorioPdf").addEventListener("click",exportarRelatorioPdf);
 $("#abrirArquivados").addEventListener("click",abrirArquivados);
 $("#proximaDemanda").addEventListener("click",irParaProxima);
 $("#filtroData").addEventListener("change",render);
 $("#fecharLixeira").addEventListener("click",fecharLixeira);
 $("#fecharHistorico").addEventListener("click",()=>$("#historicoModal").classList.add("oculto"));
 $("#fecharArquivados").addEventListener("click",()=>$("#arquivadosModal").classList.add("oculto"));
 $("#fecharStatusModal").addEventListener("click",fecharStatusModal);
 $("#exportarBackup").addEventListener("click",exportarBackup); $("#pvEscolherPasta")?.addEventListener("click",()=>PVStorage.chooseFolder()); PVStorage.updateFolderUI();
 $("#importarBackup").addEventListener("change",importarBackup);
}
/* Janela de "vai atrasar em breve": prazo dentro das próximas 48h, mas ainda não vencido. */
const JANELA_VENCENDO_MS=48*3600000;
function vaiAtrasar(p){const l=limitePedido(p);return !finalizado(p)&&!atrasado(p)&&l!==null&&(l-Date.now())<=JANELA_VENCENDO_MS}
function tempoParaVencer(p){
 const l=limitePedido(p); if(l===null)return "";
 let ms=Math.max(0,l-Date.now());
 const h=Math.floor(ms/3600000); ms-=h*3600000; const m=Math.floor(ms/60000);
 return h>0?`vence em ${h}h ${String(m).padStart(2,"0")}min`:`vence em ${m}min`;
}
/* "Entra em produção": ainda não começou a ser produzido (aguardando material / matéria-prima). */
function aguardandoProducao(p){return !finalizado(p)&&p.status==="material"}

function abrirRelatorio(){
 const m=$("#relatorioModal"); if(!m)return; m.classList.remove("oculto");
 document.querySelectorAll(".rel-tab").forEach(x=>x.classList.remove("ativo")); $("#relatorioPrioridades").classList.add("ativo"); renderRelatorio("prioridades");
}
function renderRelatorio(modo){
 const el=$("#relatorioConteudo"); if(!el)return;
 const ativos=pedidos.filter(p=>!finalizado(p)), ats=pedidos.filter(p=>atrasado(p));
 const hoje=new Date().toISOString().slice(0,10), sem=new Date(Date.now()+7*86400000).toISOString().slice(0,10);
 const hojeN=ativos.filter(p=>(p.prazo||"")===hoje).length, semN=ativos.filter(p=>(p.prazo||"")>=hoje&&(p.prazo||"")<=sem).length;
 const totalU=pedidos.reduce((n,p)=>n+totalQuantidade(p),0);
 if(modo==="prioridades"){
  const vencendo=ativos.filter(vaiAtrasar).sort((a,b)=>(limitePedido(a)||0)-(limitePedido(b)||0));
  const aguardando=ativos.filter(aguardandoProducao).sort((a,b)=>(limitePedido(a)||Infinity)-(limitePedido(b)||Infinity));
  const item=(p,cls,emoji,extra)=>"<div class=\""+cls+"\"><strong>"+emoji+" "+esc(p.cliente||"Sem cliente")+"</strong> — "+esc(pedidoResumoParaTela(p))+"<div class=\"meta\">OS "+esc(p.os||"—")+" · "+totalQuantidade(p)+" un. · "+esc(STATUS[p.status]||"EM PRODUÇÃO")+" · "+extra+"</div></div>";
  const atrasoHtml=ats.length?ats.sort((a,b)=>(limitePedido(a)||0)-(limitePedido(b)||0)).map(p=>item(p,"rel-atraso","🔴","atrasado "+esc(contadorAtraso(p)))).join(""):"<div class=\"rel-vazio\">✅ Nada atrasado agora.</div>";
  const vencendoHtml=vencendo.length?vencendo.map(p=>item(p,"rel-vence","🟠",esc(tempoParaVencer(p)))).join(""):"<div class=\"rel-vazio\">Nenhuma demanda vence nas próximas 48h.</div>";
  const aguardandoHtml=aguardando.length?aguardando.map(p=>item(p,"rel-fila","🔵",p.prazo?"prazo "+new Date(p.prazo+"T00:00:00").toLocaleDateString("pt-BR"):"sem prazo definido")).join(""):"<div class=\"rel-vazio\">Nada aguardando material no momento.</div>";
  el.innerHTML=
   "<div class=\"rel-resumo\"><div class=\"rel-kpi red\"><b>"+ats.length+"</b><span>ATRASADAS AGORA</span></div><div class=\"rel-kpi orange\"><b>"+vencendo.length+"</b><span>VÃO ATRASAR (48H)</span></div><div class=\"rel-kpi\"><b>"+aguardando.length+"</b><span>AGUARDANDO MATERIAL</span></div><div class=\"rel-kpi green\"><b>"+pedidos.filter(p=>p.status==="pronto").length+"</b><span>PRONTAS</span></div></div>"+
   "<div class=\"rel-secao\"><h3>🔴 Atrasado agora <span class=\"cnt\">"+ats.length+"</span></h3>"+atrasoHtml+"</div>"+
   "<div class=\"rel-secao\"><h3>🟠 Vai atrasar nas próximas 48h <span class=\"cnt\">"+vencendo.length+"</span></h3>"+vencendoHtml+"</div>"+
   "<div class=\"rel-secao\"><h3>🔵 Aguardando material / vai entrar em produção <span class=\"cnt\">"+aguardando.length+"</span></h3>"+aguardandoHtml+"</div>";
  return;
 }
 const st={},tip={},set={};
 pedidos.forEach(p=>{st[p.status||"sem_status"]=(st[p.status||"sem_status"]||0)+1;(p.setores||[]).forEach(x=>set[x]=(set[x]||0)+1);itensDoPedido(p).forEach(i=>{const k=i.tipo||"Outro";tip[k]=(tip[k]||0)+(Number(i.quantidade)||0)})});
 const rows=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]).map(([k,v])=>"<div class=\"rel-row\"><b>"+esc(k)+"</b><strong>"+v+"</strong></div>").join("")||"<div class=\"rel-vazio\">Sem dados.</div>";
 el.innerHTML="<div class=\"rel-resumo\"><div class=\"rel-kpi\"><b>"+pedidos.length+"</b><span>TOTAL DE OS</span></div><div class=\"rel-kpi\"><b>"+totalU+"</b><span>TOTAL DE UNIDADES</span></div><div class=\"rel-kpi red\"><b>"+ats.length+"</b><span>ATRASADAS</span></div><div class=\"rel-kpi green\"><b>"+pedidos.filter(p=>p.status==="pronto").length+"</b><span>PRONTAS</span></div></div><div class=\"rel-resumo\"><div class=\"rel-kpi\"><b>"+ativos.length+"</b><span>EM ABERTO</span></div><div class=\"rel-kpi orange\"><b>"+hojeN+"</b><span>VENCEM HOJE</span></div><div class=\"rel-kpi\"><b>"+semN+"</b><span>PRÓXIMOS 7 DIAS</span></div><div class=\"rel-kpi\"><b>"+pedidos.filter(p=>p.status==="entregue").length+"</b><span>ENTREGUES</span></div></div><div class=\"rel-grid\"><div class=\"rel-box\"><h4>POR STATUS</h4><div class=\"rel-list\">"+rows(st)+"</div></div><div class=\"rel-box\"><h4>UNIDADES POR TIPO DE PRODUTO</h4><div class=\"rel-list\">"+rows(tip)+"</div></div></div><div class=\"rel-box\"><h4>DEMANDAS POR SETOR</h4><div class=\"rel-list\">"+rows(set)+"</div></div>";
}
async function exportarRelatorioPdf(){
 if(!window.jspdf?.jsPDF||typeof PDFUtil==="undefined"||typeof PDFUtil.relatorio!=="function"){alert("Biblioteca de PDF não disponível.");return}
 const ativos=pedidos.filter(p=>!finalizado(p)),ats=pedidos.filter(p=>atrasado(p));
 const vencendo=ativos.filter(vaiAtrasar).sort((a,b)=>(limitePedido(a)||0)-(limitePedido(b)||0));
 const aguardando=ativos.filter(aguardandoProducao).sort((a,b)=>(limitePedido(a)||Infinity)-(limitePedido(b)||Infinity));
 const totalU=pedidos.reduce((n,p)=>n+totalQuantidade(p),0),atsU=ats.reduce((n,p)=>n+totalQuantidade(p),0);
 const st={},tip={},set={};
 pedidos.forEach(p=>{const k=STATUS[p.status]||"SEM STATUS";st[k]=(st[k]||0)+1;(p.setores||[]).forEach(x=>set[x]=(set[x]||0)+1);itensDoPedido(p).forEach(i=>{const t=i.tipo||"Outro";tip[t]=(tip[t]||0)+(Number(i.quantidade)||0)})});
 const ord=o=>Object.entries(o).sort((a,b)=>b[1]-a[1]);
 const linha=(p,extra)=>({cliente:p.cliente||"Sem cliente",resumo:pedidoResumoParaTela(p),os:p.os||"—",un:totalQuantidade(p),
   prazo:p.prazo?new Date(p.prazo+"T00:00:00").toLocaleDateString("pt-BR"):(p.horaMarcada?fmtDataHora(p.horaMarcada):"—"),status:STATUS[p.status]||"EM PRODUÇÃO",extra});
 const dados={
  titulo:"RELATÓRIO DE PRODUÇÃO — PRIORIDADES",
  subtitulo:"Gerado em "+new Date().toLocaleString("pt-BR"),
  kpis:[
   {label:"Atrasadas agora",valor:ats.length,cor:"red"},{label:"Vão atrasar (48h)",valor:vencendo.length,cor:"orange"},
   {label:"Aguardando material",valor:aguardando.length,cor:"blue"},{label:"Prontas",valor:pedidos.filter(p=>p.status==="pronto").length,cor:"green"},
   {label:"Total de OS",valor:pedidos.length,cor:"blue"},{label:"Total de unidades",valor:totalU,cor:"blue"},
   {label:"Unidades em atraso",valor:atsU,cor:"orange"},{label:"Em aberto",valor:ativos.length,cor:"blue"}
  ],
  atrasos:[...ats].sort((a,b)=>(limitePedido(a)||0)-(limitePedido(b)||0)).map(p=>linha(p,contadorAtraso(p))),
  vencendo:vencendo.map(p=>linha(p,tempoParaVencer(p))),
  aguardando:aguardando.map(p=>linha(p,p.prazo?("prazo "+new Date(p.prazo+"T00:00:00").toLocaleDateString("pt-BR")):"sem prazo")),
  grupos:[
   {titulo:"OS por status",cor:"blue",dados:ord(st)},
   {titulo:"Unidades por tipo de produto",cor:"green",dados:ord(tip)},
   {titulo:"OS por setor",cor:"orange",dados:ord(set)}
  ]
 };
 try{
  const x=await PVStorage.get({empresa:{nome:"New Print Midia",logo:""}});
  await PDFUtil.relatorio(dados,x.empresa||{},"relatorio-prioridades-"+new Date().toISOString().slice(0,10)+".pdf");
 }catch(err){console.error(err);alert("Não foi possível gerar o PDF do relatório: "+(err?.message||err))}
}

function exportarBackup(){
 PVStorage.get(null,x=>{
  const dados={
   versao:2,
   geradoEm:new Date().toISOString(),
   pedidos:x.pedidos||[],
   lixeira:x.lixeira||[],
   arquivados:x.arquivados||[],
   empresa:x.empresa||{},
   npPrices:x.npPrices||[],
   vozConfig:x.vozConfig||{}
  };
  const blob=new Blob([JSON.stringify(dados,null,2)],{type:"application/json"});
  const url=URL.createObjectURL(blob);
  const a=document.createElement("a");
  const dataHoje=new Date().toISOString().slice(0,10);
  a.href=url;a.download=`producao-vip-backup-${dataHoje}.json`;
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),2000);
 });
}
function importarBackup(ev){
 const file=ev.target.files&&ev.target.files[0];
 ev.target.value="";
 if(!file)return;
 const leitor=new FileReader();
 leitor.onload=()=>{
  let dados;
  try{dados=JSON.parse(leitor.result)}catch(e){alert("Arquivo inválido — não é um backup do New Print Midia.");return}
  if(!dados||!Array.isArray(dados.pedidos)){alert("Arquivo inválido — não é um backup do New Print Midia.");return}
  const modo=confirm(
   `Backup de ${dados.geradoEm?new Date(dados.geradoEm).toLocaleString("pt-BR"):"data desconhecida"} com ${dados.pedidos.length} pedido(s).\n\n`+
   `OK = MESCLAR com os pedidos atuais (recomendado)\nCancelar = SUBSTITUIR tudo pelo backup`
  );
  PVStorage.get({pedidos:[],lixeira:[]},x=>{
   let novosPedidos,novaLixeira;
   if(modo){
    const porId=new Map(x.pedidos.map(p=>[p.id,p]));
    dados.pedidos.forEach(p=>porId.set(p.id,p));
    novosPedidos=[...porId.values()];
    const porIdLix=new Map((x.lixeira||[]).map(p=>[p.id,p]));
    (dados.lixeira||[]).forEach(p=>porIdLix.set(p.id,p));
    novaLixeira=[...porIdLix.values()];
   }else{
    novosPedidos=dados.pedidos;
    novaLixeira=dados.lixeira||[];
   }
   const salvar={pedidos:novosPedidos,lixeira:novaLixeira,arquivados:dados.arquivados||[],...(Array.isArray(dados.npPrices)?{npPrices:dados.npPrices}:{})};
   if(dados.empresa)salvar.empresa=dados.empresa;
   if(dados.vozConfig)salvar.vozConfig=dados.vozConfig;
   PVStorage.set(salvar,()=>{
    pedidos=novosPedidos;
    if(dados.empresa)aplicarEmpresa(dados.empresa);
    render();
    alert("Backup importado com sucesso!");
   });
  });
 };
 leitor.readAsText(file);
}
function abrirConfig(){PVStorage.get({empresa:{nome:"New Print Midia",logo:""},usuario:{nome:"",funcao:""}},x=>{const e=x.empresa||{};const u=x.usuario||{};$("#empresaNome").value=e.nome||"New Print Midia";$("#usuarioNome").value=u.nome||"";$("#usuarioFuncao").value=u.funcao||"";$("#configModal").dataset.logo=e.logo||"";mostrarPreview(e.logo||"");$("#configModal").classList.remove("oculto");carregarFormVoz();$("#empresaNome").focus()})}
function fecharConfig(){$("#configModal").classList.add("oculto")}
function previewLogo(ev){const file=ev.target.files&&ev.target.files[0];if(!file)return;if(file.size>3*1024*1024){alert("Escolha uma imagem de até 3 MB.");ev.target.value="";return}redimensionarImagem(file,260,0.82,data=>{$("#configModal").dataset.logo=data;mostrarPreview(data)})}
function mostrarPreview(src){if(src){$("#previewLogo").src=src;$("#previewLogo").style.display="block";$("#semLogo").style.display="none"}else{$("#previewLogo").removeAttribute("src");$("#previewLogo").style.display="none";$("#semLogo").style.display="block"}}
function aplicarEmpresa(e){const nome=(e&&e.nome?e.nome:"New Print Midia").trim().replace(/^Produção VIP$/i,"New Print Midia")||"New Print Midia";$("#nomeEmpresa").textContent=nome;if(e&&e.logo){$("#logoEmpresa").src=e.logo;$("#logoEmpresa").style.display="block";$("#logoFallback").style.display="none"}else{$("#logoEmpresa").removeAttribute("src");$("#logoEmpresa").style.display="none";$("#logoFallback").style.display="inline"}document.title=nome}
function salvarConfig(){const nome=$("#empresaNome").value.trim()||"New Print Midia";const logo=$("#configModal").dataset.logo||"";const usuario={nome:$("#usuarioNome").value.trim(),funcao:$("#usuarioFuncao").value.trim()};window.__pvUsuarioNome=usuario.nome;window.__pvUsuarioFuncao=usuario.funcao;PVStorage.set({empresa:{nome,logo},usuario,vozConfig:lerFormVoz()},()=>{aplicarEmpresa({nome,logo});fecharConfig()})}
function redimensionarImagem(file,max,quality,cb){const r=new FileReader();r.onload=()=>{const img=new Image();img.onload=()=>{const scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement("canvas");c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));c.getContext("2d").drawImage(img,0,0,c.width,c.height);cb(c.toDataURL("image/jpeg",quality))};img.src=r.result};r.readAsDataURL(file)}
async function previewImagemPedido(ev){
 const files=[...(ev.target.files||[])]; if(!files.length)return;
 const valid=files.filter(f=>f.type.startsWith('image/') && f.size<=5*1024*1024);
 if(valid.length!==files.length){alert('Cada imagem deve ser PNG, JPG ou WEBP e ter até 5 MB.');}
 const imagens=[];
 for(const file of valid){imagens.push(await redimensionarImagemPromise(file,1400,0.82));}
 if(!imagens.length)return;
 const antigas=getImagensFormulario();
 const todas=[...antigas,...imagens].slice(0,12);
 setImagensFormulario(todas); renderPreviewFormulario();
}
function redimensionarImagemPromise(file,max,quality){return new Promise((resolve,reject)=>{redimensionarImagem(file,max,quality,resolve)})}
function getImagensFormulario(){
 const raw=$('#form').dataset.imagensPedido||'';
 try{return JSON.parse(raw)}catch(e){return []}
}
function setImagensFormulario(imagens){
 const arr=Array.isArray(imagens)?imagens.filter(Boolean).slice(0,12):[];
 $('#form').dataset.imagensPedido=JSON.stringify(arr);
 $('#form').dataset.imagemPedido=arr[0]||'';
}
function renderPreviewFormulario(){
 const box=$('#previewPedido'); const imgs=getImagensFormulario();
 if(!imgs.length){box.innerHTML='<span id="semImagemPedido">Nenhuma imagem adicionada</span>';$('#removerImagemPedido').style.display='none';return}
 box.innerHTML=imgs.map((src,i)=>`<div class="preview-item"><img src="${src}" alt="Referência ${i+1}"><span>${i+1}</span></div>`).join('');
 $('#removerImagemPedido').style.display='inline-flex';
}
async function previewDocumentoOS(ev){
 const files=[...(ev.target.files||[])].filter(f=>f.type.startsWith('image/')&&f.size<=8*1024*1024).slice(0,2);
 if(!files.length){if(ev.target.files&&ev.target.files.length)alert('O documento deve ser PNG, JPG ou WEBP e ter até 8 MB por imagem.');return}
 const docs=[];
 for(const file of files) docs.push(await prepararDocumentoOS(file));
 setDocumentosOS(docs); renderPreviewDocumentoOS();
}
function prepararDocumentoOS(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>{const img=new Image();img.onload=()=>{const maxSide=2400;const scale=Math.min(1,maxSide/Math.max(img.width,img.height));const w=Math.max(1,Math.round(img.width*scale)),h=Math.max(1,Math.round(img.height*scale));const c=document.createElement('canvas');c.width=w;c.height=h;const ctx=c.getContext('2d');ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.fillStyle='#fff';ctx.fillRect(0,0,w,h);ctx.drawImage(img,0,0,w,h);resolve(c.toDataURL('image/jpeg',.95));};img.onerror=reject;img.src=r.result};r.onerror=reject;r.readAsDataURL(file)})}
function getDocumentosOS(){try{return JSON.parse($('#form').dataset.documentosOS||'[]')}catch(e){return []}}
function setDocumentosOS(docs){const arr=Array.isArray(docs)?docs.filter(Boolean).slice(0,2):[];$('#form').dataset.documentosOS=JSON.stringify(arr)}
function renderPreviewDocumentoOS(){const box=$('#previewDocumentoOS');const docs=getDocumentosOS();if(!docs.length){box.innerHTML='<span id="semDocumentoOS">Nenhum documento da OS anexado</span>';$('#removerDocumentoOS').style.display='none';return}box.innerHTML=docs.map((src,i)=>`<div class="documento-preview-item"><img src="${src}" alt="Documento OS ${i+1}"><span>OS ${i+1}</span></div>`).join('');$('#removerDocumentoOS').style.display='inline-flex'}
function removerDocumentoOS(){$('#documentoOS').value='';setDocumentosOS([]);renderPreviewDocumentoOS()}

function coletarSetores(){return [...document.querySelectorAll('input[name="setor"]:checked')].map(x=>x.value)}
function itemVazio(){return {id:`item-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,tipo:"",descricao:"",quantidade:1};}
function normalizarItens(itens){
 const arr=Array.isArray(itens)?itens:[];
 return arr.map((x,i)=>({id:x.id||`item-${Date.now()}-${i}`,tipo:String(x.tipo||x.tipoProduto||""),descricao:String(x.descricao||x.nome||x.item||""),quantidade:Math.max(1,Number(x.quantidade)||1)})).filter(x=>x.tipo||x.descricao||x.quantidade);
}
function itensDoPedido(p){
 const atuais=normalizarItens(p&&p.itens);
 if(atuais.length)return atuais;
 if(p&&(p.pedido||p.tipoProduto||p.quantidade)) return [{id:"item-legado",tipo:p.tipoProduto||"",descricao:p.pedido||"",quantidade:Math.max(1,Number(p.quantidade)||1)}];
 return [];
}
function resumoItens(p){
 return itensDoPedido(p).map(x=>`${x.quantidade}x ${x.descricao||x.tipo||"item"}`).join(" · ");
}
function totalQuantidade(p){return itensDoPedido(p).reduce((n,x)=>n+(Number(x.quantidade)||0),0)||Math.max(1,Number(p&&p.quantidade)||1);}
function tiposItens(p){return [...new Set(itensDoPedido(p).map(x=>x.tipo).filter(Boolean))].join(" · ");}
function pedidoResumoParaTela(p){return p.pedido||resumoItens(p)||"Demanda sem descrição";}
function atualizarTotalItensForm(){
 const rows=[...document.querySelectorAll(".item-row")];
 const total=rows.reduce((n,row)=>n+Math.max(1,Number(row.querySelector(".item-qtd")?.value)||1),0);
 const label=rows.length===1?"item":"itens";
 $("#itensTotal").textContent=`${rows.length} ${label} · ${total} ${total===1?"unidade":"unidades"}`;
}
function criarItemRow(item=itemVazio()){
 const row=document.createElement("div"); row.className="item-row"; row.dataset.id=item.id;
 const opts=['<option value="">Tipo / produto</option>',...ITEM_TIPOS.map(t=>`<option value="${esc(t)}">${esc(t)}</option>`)].join("");
 row.innerHTML=`<select class="item-tipo">${opts}</select><input class="item-descricao" placeholder="Descrição / modelo / especificação" value="${esc(item.descricao||"")}"><input class="item-qtd" type="number" min="1" value="${Math.max(1,Number(item.quantidade)||1)}" title="Quantidade"><button type="button" class="btn-remover-item" title="Remover item">×</button>`;
 row.querySelector(".item-tipo").value=item.tipo||"";
 row.querySelector(".btn-remover-item").addEventListener("click",()=>{row.remove();if(!document.querySelector(".item-row"))adicionarItemForm();atualizarTotalItensForm()});
 row.querySelector(".item-qtd").addEventListener("input",atualizarTotalItensForm);
 row.querySelector(".item-descricao").addEventListener("input",atualizarTotalItensForm);
 return row;
}
function adicionarItemForm(item){const box=$("#itensLista");box.appendChild(criarItemRow(item||itemVazio()));atualizarTotalItensForm();const last=box.lastElementChild;last?.querySelector(".item-descricao")?.focus()}
function setItensFormulario(itens){const box=$("#itensLista");box.innerHTML="";const arr=normalizarItens(itens);(arr.length?arr:[itemVazio()]).forEach(x=>box.appendChild(criarItemRow(x)));atualizarTotalItensForm()}
function getItensFormulario(){
 return [...document.querySelectorAll(".item-row")].map(row=>({id:row.dataset.id||itemVazio().id,tipo:row.querySelector(".item-tipo")?.value||"",descricao:row.querySelector(".item-descricao")?.value.trim()||"",quantidade:Math.max(1,Number(row.querySelector(".item-qtd")?.value)||1)})).filter(x=>x.tipo||x.descricao);
}
function resumoFormulario(itens){return itens.map(x=>`${x.quantidade}x ${x.descricao||x.tipo}`).join(" · ");}

function gerarResumoAlteracoes(a,b){
 const campos=[
  ["cliente","Cliente"],["os","OS"],["prazo","Prazo"],["horaMarcada","Hora marcada"],["status","Status"],["prioridade","Prioridade"],["retirada","Retirada"],["pagamentoStatus","Pagamento"],["pagamentoForma","Forma de pagamento"],["observacoes","Observações"]
 ];
 const out=[];
 for(const [k,nome] of campos){let av=a?.[k]??"",bv=b?.[k]??"";if(String(av)!==String(bv))out.push(`${nome}: ${av||"—"} → ${bv||"—"}`)}
 const sa=(a?.setores||[]).join(", "),sb=(b?.setores||[]).join(", ");if(sa!==sb)out.push(`Setores: ${sa||"—"} → ${sb||"—"}`);
 const ia=JSON.stringify(a?.itens||[]),ib=JSON.stringify(b?.itens||[]);if(ia!==ib)out.push("Itens/quantidades alterados");
 return out;
}

function salvar(){
 const cliente=$('#cliente').value.trim(), telefone=$('#telefone').value.trim(), pedidoDigitado=$('#pedido').value.trim();
 const prazo=$('#prazo').value;
 const itens=getItensFormulario();
 if(!cliente){alert('Informe o cliente.');$('#cliente').focus();return}
 if(!itens.length){alert('Adicione pelo menos um item à demanda.');$('#adicionarItem').focus();return}
 if(!prazo){alert('Informe o prazo de entrega.');$('#prazo').focus();return}
 const pedido=pedidoDigitado||resumoFormulario(itens);
 const quantidade=itens.reduce((n,x)=>n+x.quantidade,0);
 const tipoProduto=[...new Set(itens.map(x=>x.tipo).filter(Boolean))].join(' · ');
 const imagens=getImagensFormulario();
 const documentosOS=getDocumentosOS();
 const endereco={cep:$('#endCep').value.trim(),rua:$('#endRua').value.trim(),numero:$('#endNumero').value.trim(),complemento:$('#endComplemento').value.trim(),bairro:$('#endBairro').value.trim(),cidade:$('#endCidade').value.trim(),referencia:$('#endReferencia').value.trim()};
 const dados={cliente,telefone,pedido,itens,os:$('#os').value.trim(),tipoProduto,quantidade,entrada:$('#entrada').value||new Date().toISOString().slice(0,10),prazo,status:$('#status').value||'producao',prioridade:$('#prioridade').value||'Normal',fixado:false,retirada:$('#retirada').value||'',endereco,horaMarcada:$('#horaMarcada').value||'',pagamentoStatus:$('#pagamentoStatus').value||'',pagamentoForma:$('#pagamentoForma').value||'',pagamentoParcelas:Math.max(1,Number($('#pagamentoParcelas').value)||1),pagamentoDetalhes:$('#pagamentoDetalhes').value.trim(),setores:coletarSetores(),primeiroSetor:document.querySelector("#primeiroSetor")?.value||"",imagensPedido:imagens,imagemPedido:imagens[0]||'',documentosOS,documentoOS:documentosOS[0]||'',observacoes:$('#observacoes').value.trim()};
 const editing=$('#form').dataset.editing;
 if(editing){
   const idx=pedidos.findIndex(p=>p.id===editing);
   if(idx<0){alert('Pedido não encontrado.');return}
   const anterior=pedidos[idx];
   const historico=Array.isArray(anterior.historico)?anterior.historico:[];
   const alteracoes=gerarResumoAlteracoes(anterior,dados);
   pedidos[idx]={...anterior,...dados,id:anterior.id,criado:anterior.criado||Date.now(),fixado:!!anterior.fixado,historico};
   if(alteracoes.length){historico.push(eventoHistorico("Dados da demanda alterados",{status:dados.status,alteracoes}));}
   PVStorage.set({pedidos},()=>{
     if(chrome.runtime.lastError){alert('Erro ao salvar: '+chrome.runtime.lastError.message);return}
     render();$('#form').classList.add('oculto');
     if(dados.status!==anterior.status)avisarStatus(pedidos[idx],anterior.status);
     if(STATUS_PRODUCAO.has(dados.status)&&!STATUS_PRODUCAO.has(anterior.status))avisarEntradaProducao(pedidos[idx]);
     if(dados.status==='pronto'&&anterior.status!=='pronto')avisarPronto(pedidos[idx]);
     if(dados.status!==anterior.status&&pagamentoPendente(pedidos[idx]))avisarPagamentoPendente(pedidos[idx]);
   });
 }else{
   const agora=Date.now();
   const novo={...dados,id:`pedido-${agora}-${Math.random().toString(36).slice(2,8)}`,criado:agora,fixado:false,historico:[{...eventoHistorico("Pedido criado",{status:dados.status}),t:agora}]};
   pedidos.push(novo);
   PVStorage.set({pedidos},()=>{
     if(chrome.runtime.lastError){pedidos=pedidos.filter(p=>p.id!==novo.id);alert('Erro ao salvar: '+chrome.runtime.lastError.message);return}
     render();$('#form').classList.add('oculto');avisarNovaDemanda(novo);
     if(STATUS_PRODUCAO.has(novo.status))avisarEntradaProducao(novo);
   });
 }
}
function limpar(){
 ["cliente","telefone","pedido","os","prazo","observacoes","horaMarcada","imagemPedido","pagamentoDetalhes","endCep","endRua","endNumero","endComplemento","endBairro","endCidade","endReferencia"].forEach(id=>{const el=$("#"+id);if(el)el.value=""});
 $("#retirada").value="";atualizarEndereco();$("#status").value="producao";$("#prioridade").value="Normal";$("#pagamentoStatus").value="";$("#pagamentoForma").value="";$("#pagamentoParcelas").value=1;
 delete $("#form").dataset.imagemPedido;delete $("#form").dataset.imagensPedido;delete $("#form").dataset.documentosOS;delete $("#form").dataset.editing;setItensFormulario([]);
 $("#previewPedido").innerHTML='<span id="semImagemPedido">Nenhuma imagem adicionada</span>';$("#removerImagemPedido").style.display="none";$("#documentoOS").value="";renderPreviewDocumentoOS();
 $("#formTitulo").textContent="Novo pedido";$("#salvar").textContent="SALVAR PEDIDO";
}
function removerImagemPedido(){setImagensFormulario([]);$("#imagemPedido").value="";renderPreviewFormulario();}
function abrirEdicao(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 $("#form").classList.remove("oculto");$("#form").dataset.editing=p.id;$("#form").dataset.imagemPedido=p.imagemPedido||"";
 $("#formTitulo").textContent="Editar pedido";$("#salvar").textContent="SALVAR ALTERAÇÕES";
 document.querySelector("#primeiroSetor").value=p.primeiroSetor||"";$("#cliente").value=p.cliente||"";$("#telefone").value=p.telefone||"";$("#pedido").value=p.pedido||"";$("#os").value=p.os||"";document.querySelectorAll("input[name=\"setor\"]").forEach(c=>c.checked=Array.isArray(p.setores)&&p.setores.includes(c.value));setItensFormulario(itensDoPedido(p));$("#entrada").value=p.entrada||"";$("#prazo").value=p.prazo||"";$("#status").value=p.status||"producao";$("#prioridade").value=p.prioridade||"Normal";$("#retirada").value=p.retirada||"";const e=p.endereco||{};$("#endCep").value=e.cep||"";$("#endRua").value=e.rua||"";$("#endNumero").value=e.numero||"";$("#endComplemento").value=e.complemento||"";$("#endBairro").value=e.bairro||"";$("#endCidade").value=e.cidade||"";$("#endReferencia").value=e.referencia||"";atualizarEndereco();$("#horaMarcada").value=p.horaMarcada||"";$("#observacoes").value=p.observacoes||"";$("#pagamentoStatus").value=p.pagamentoStatus||"";$("#pagamentoForma").value=p.pagamentoForma||"";$("#pagamentoParcelas").value=p.pagamentoParcelas||1;$("#pagamentoDetalhes").value=p.pagamentoDetalhes||"";$("#imagemPedido").value="";setImagensFormulario(Array.isArray(p.imagensPedido)&&p.imagensPedido.length?p.imagensPedido:(p.imagemPedido?[p.imagemPedido]:[]));
 $("#documentoOS").value="";setDocumentosOS(Array.isArray(p.documentosOS)&&p.documentosOS.length?p.documentosOS:(p.documentoOS?[p.documentoOS]:[]));
 renderPreviewFormulario();renderPreviewDocumentoOS();
 $("#form").scrollIntoView({behavior:"smooth",block:"start"});$("#cliente").focus();
}
function atualizarEndereco(){const ativo=$("#retirada").value==="Empresa vai até o cliente";$("#enderecoBox").classList.toggle("oculto",!ativo);}
function enderecoResumo(p){const e=p.endereco||{};const partes=[];if(e.rua)partes.push(e.rua+(e.numero?`, ${e.numero}`:""));if(e.complemento)partes.push(e.complemento);if(e.bairro)partes.push(e.bairro);if(e.cidade)partes.push(e.cidade);if(e.cep)partes.push(`CEP ${e.cep}`);return partes.join(" · ");}
function limitePedido(p){
 const hm=p.horaMarcada?new Date(p.horaMarcada):null;
 if(hm && !Number.isNaN(hm.getTime())) return hm.getTime();
 if(p.prazo){
   const d=new Date(p.prazo+"T23:59:59");
   if(!Number.isNaN(d.getTime())) return d.getTime();
 }
 return null;
}
function finalizado(p){return ["pronto","entregue","cancelado"].includes(p.status)}
function pagamentoPendente(p){return (p.status==="pronto"||p.status==="entregue")&&p.pagamentoStatus&&!["quitado","patrocinio"].includes(p.pagamentoStatus)}
function atrasado(p){const l=limitePedido(p);return !finalizado(p)&&l!==null&&Date.now()>=l}
function dias(p){const l=limitePedido(p);return l===null?0:Math.ceil((l-Date.now())/86400000)}
function contadorAtraso(p){
 const l=limitePedido(p); if(l===null||Date.now()<l)return "";
 let ms=Date.now()-l;
 const dias=Math.floor(ms/86400000); ms-=dias*86400000;
 const horas=Math.floor(ms/3600000); ms-=horas*3600000;
 const minutos=Math.floor(ms/60000); const segundos=Math.floor((ms%60000)/1000);
 return `${String(dias).padStart(2,"0")}d ${String(horas).padStart(2,"0")}h ${String(minutos).padStart(2,"0")}m ${String(segundos).padStart(2,"0")}s`;
}
function estado(p){if(p.status==="pronto")return["b-green","PRONTO"];if(p.status==="entregue")return["b-blue","ENTREGUE"];if(p.status==="cancelado")return["b-gray","CANCELADO"];return atrasado(p)?["b-red","ATRASADO · "+(STATUS[p.status]||"")]:["b-blue",STATUS[p.status]||"EM PRODUÇÃO"]}
const PESO_PRIORIDADE={Urgente:0,Alta:1,Normal:2,Baixa:3};
// Atrasado sempre primeiro; depois por prioridade (Alta > Normal > Baixa); por fim, o mais antigo primeiro.
function ordemLista(a,b){
 const atrA=atrasado(a)?0:(a.fixado?1:2),atrB=atrasado(b)?0:(b.fixado?1:2);
 if(atrA!==atrB)return atrA-atrB;
 const pA=PESO_PRIORIDADE[a.prioridade]??1,pB=PESO_PRIORIDADE[b.prioridade]??1;
 if(pA!==pB)return pA-pB;
 return (Number(a.criado)||0)-(Number(b.criado)||0);
}
function render(){
 const q=$("#busca").value.toLowerCase(),f=$("#filtro").value,fd=$("#filtroData")?.value||"";
 const lista=pedidos.filter(p=>{
   const texto=`${p.cliente} ${p.telefone} ${pedidoResumoParaTela(p)} ${resumoItens(p)} ${p.os||""}`.toLowerCase();
   return (!q||texto.includes(q))&&(!f||(f==="atrasado"?atrasado(p):p.status===f))&&(!fd||(fd==="hoje"?((p.prazo||"")===new Date().toISOString().slice(0,10)):fd==="amanha"?((p.prazo||"")===new Date(Date.now()+86400000).toISOString().slice(0,10)):fd==="semana"?((p.prazo||"")>=new Date().toISOString().slice(0,10)&&(p.prazo||"")<=new Date(Date.now()+7*86400000).toISOString().slice(0,10)):true));
 });
 $("#qtdTotal").textContent=pedidos.length;
 $("#qtdProducao").textContent=pedidos.filter(p=>["corte","producao","costura","estamparia","material"].includes(p.status)).length;
 $("#qtdPronto").textContent=pedidos.filter(p=>p.status==="pronto").length;
 $("#qtdAtrasado").textContent=pedidos.filter(p=>atrasado(p)).length;
 const pendentesPag=pedidos.filter(pagamentoPendente);
 $("#qtdPendentePag").textContent=pendentesPag.length;
 if($("#qtdHoje")) $("#qtdHoje").textContent=pedidos.filter(p=>(p.prazo||"")===new Date().toISOString().slice(0,10)&&!finalizado(p)).length;
 if($("#qtdSemana")) $("#qtdSemana").textContent=pedidos.filter(p=>{const h=new Date().toISOString().slice(0,10),s=new Date(Date.now()+7*86400000).toISOString().slice(0,10);return (p.prazo||"")>=h&&(p.prazo||"")<=s&&!finalizado(p)}).length;

 const alertas=pedidos.filter(p=>!finalizado(p)&&((limitePedido(p)!==null&&Date.now()>=limitePedido(p))||dias(p)<=1));
 const alertasHtml=alertas.map(p=>{
   const a=atrasado(p), c=contadorAtraso(p);
   return `<div class="alerta ${a?"red":"yellow"}">${a?"🔴":"🟡"} <b>${esc(p.cliente)}</b> — ${a?"PEDIDO ATRASADO":"PRAZO PRÓXIMO"} · ${esc(pedidoResumoParaTela(p))} ${a?`<span class="atraso-contagem">${c}</span>`:""} <span class="alerta-status">${esc(STATUS[p.status]||"EM PRODUÇÃO")}</span></div>`;
 }).join("");
 const alertasPagHtml=pendentesPag.map(p=>`<div class="alerta purple">💜 <b>${esc(p.cliente)}</b> — PAGAMENTO PENDENTE · ${esc(pedidoResumoParaTela(p))} <span class="alerta-status">${esc(nomePagamento(p.pagamentoStatus))}</span></div>`).join("");
 $("#alertas").innerHTML=alertasHtml+alertasPagHtml;

 const out=$("#lista");
 if(!lista.length){out.innerHTML='<div class="vazio">Nenhum pedido encontrado.</div>';return}
 out.innerHTML=lista.sort(ordemLista).map(p=>{
   const [bc,bl]=estado(p),a=atrasado(p),d=dias(p),cont=contadorAtraso(p);
   const retirada=p.retirada?`<div class="retirada">🚗 <b>Retirada/atendimento:</b> ${esc(p.retirada)}</div>`:"";
   const endereco=(p.retirada==="Empresa vai até o cliente"&&enderecoResumo(p))?`<div class="endereco-list">📍 <b>Endereço:</b> ${esc(enderecoResumo(p))}${p.endereco&&p.endereco.referencia?` · <b>Ref.:</b> ${esc(p.endereco.referencia)}`:""}</div>`:"";
   const pagamento=p.pagamentoStatus||p.pagamentoForma?`<div class="pagamento-list">💰 <b>Pagamento:</b> ${esc(nomePagamento(p.pagamentoStatus))}${p.pagamentoForma?` · ${esc(nomePagamentoForma(p.pagamentoForma))}`:""}${p.pagamentoParcelas>1?` · ${p.pagamentoParcelas}x`:""}${p.pagamentoDetalhes?` · ${esc(p.pagamentoDetalhes)}`:""}</div>`:"";
   const hora=p.horaMarcada?`<div class="hora-marcada">⏰ <b>Hora marcada:</b> ${fmtDataHora(p.horaMarcada)}</div>`:"";
   const imgs=Array.isArray(p.imagensPedido)&&p.imagensPedido.length?p.imagensPedido:(p.imagemPedido?[p.imagemPedido]:[]);
   const img=imgs.length?`<div class="pedido-thumbs">${imgs.slice(0,6).map((src,i)=>`<img src="${src}" alt="Referência ${i+1}">`).join("")}</div>`:"";
   const itens=itensDoPedido(p);
   const itensHtml=itens.length?`<div class="itens-lista-card">${itens.map((it,i)=>`<div class="item-card"><span class="item-num">${i+1}</span><div><b>${esc(it.descricao||it.tipo||"Item")}</b>${it.tipo&&it.descricao?` <small>· ${esc(it.tipo)}</small>`:""}</div><strong>${it.quantidade} un.</strong></div>`).join("")}</div>`:"";
   const tipo=tiposItens(p)?`<div class="tipo-produto">🧾 <b>Tipos:</b> ${esc(tiposItens(p))}</div>`:"";
   const setores=p.setores&&p.setores.length?`<div class="setores-list">🏭 <b>Setores:</b> ${esc(p.setores.join(" · "))}</div>`:"";
   const docsOS=Array.isArray(p.documentosOS)&&p.documentosOS.length?p.documentosOS:(p.documentoOS?[p.documentoOS]:[]);
   const documentoBadge=docsOS.length?`<div class="documento-os-badge">📄 ${docsOS.length} documento(s) da OS anexado(s)</div>`:"";
   const prazoTexto=a
     ? `<span class="prazo-atraso">ATRASADO HÁ <span class="atraso-contagem">${cont}</span></span>`
     : `${d} dia(s) restante(s)`;
   return `<article class="pedido ${a?"pedido-atrasado":""}">
    <div class="top"><div><div class="cliente-nome">${esc(p.cliente)}</div><div class="pedido-info">${esc(pedidoResumoParaTela(p))} · ${totalQuantidade(p)} un. · ${esc(p.telefone)}${p.os?` · OS ${esc(p.os)}`:""}</div></div><span class="badge ${bc}">${bl}</span>${pagamentoPendente(p)?`<span class="badge b-purple">💜 PGTO PENDENTE</span>`:""}</div>
    <div class="card-tools"><button class="btn-fixar" data-id="${p.id}">${p.fixado?"📌 FIXADO":"📌 FIXAR"}</button><button class="btn-duplicar" data-id="${p.id}">⧉ DUPLICAR</button><button class="btn-historico" data-id="${p.id}">🕘 HISTÓRICO</button><button class="btn-arquivar" data-id="${p.id}">🗄️ ARQUIVAR</button></div>
    ${tipo}${itensHtml}${setores}${documentoBadge}${img}
    <div class="prazo">📅 Prazo: <b>${br(p.prazo)}</b> · ${prazoTexto}</div>
    ${hora}${retirada}${endereco}${pagamento}
    <div class="botoes"><button class="btn-ver-os" data-id="${p.id}" ${docsOS.length?'':'disabled'}>📄 VER OS</button><button class="btn-pendencia" data-id="${p.id}">⚠️ PENDÊNCIA</button><button class="btn-status" data-id="${p.id}">ALTERAR STATUS</button><button class="btn-editar" data-id="${p.id}">✏️ EDITAR</button><button class="whats btn-avisar" data-id="${p.id}">📲 AVISAR${(Array.isArray(p.imagensPedido)&&p.imagensPedido.length)||p.imagemPedido?" + IMG":""}</button><button class="btn-entregar" data-id="${p.id}">ENTREGUE</button><button class="btn-pdf" data-id="${p.id}">📄 PDF</button><button class="btn-deletar" data-id="${p.id}">🗑️ EXCLUIR</button></div>
   </article>`;
 }).join("");
 out.querySelectorAll(".btn-fixar").forEach(b=>b.addEventListener("click",()=>fixarPedido(b.dataset.id)));
 out.querySelectorAll(".btn-duplicar").forEach(b=>b.addEventListener("click",()=>duplicarPedido(b.dataset.id)));
 out.querySelectorAll(".btn-historico").forEach(b=>b.addEventListener("click",()=>abrirHistorico(b.dataset.id)));
 out.querySelectorAll(".btn-arquivar").forEach(b=>b.addEventListener("click",()=>arquivarPedido(b.dataset.id)));
 out.querySelectorAll(".btn-ver-os").forEach(b=>b.addEventListener("click",()=>verDocumentoOS(b.dataset.id)));
 out.querySelectorAll(".btn-pendencia").forEach(b=>b.addEventListener("click",()=>abrirEditorPendencia(b.dataset.id)));
 out.querySelectorAll(".btn-status").forEach(b=>b.addEventListener("click",()=>mudar(b.dataset.id)));
 out.querySelectorAll(".btn-editar").forEach(b=>b.addEventListener("click",()=>abrirEdicao(b.dataset.id)));
 out.querySelectorAll(".btn-avisar").forEach(b=>b.addEventListener("click",()=>menuWhats(b.dataset.id)));
 out.querySelectorAll(".btn-entregar").forEach(b=>b.addEventListener("click",()=>entregar(b.dataset.id)));
 out.querySelectorAll(".btn-deletar").forEach(b=>b.addEventListener("click",()=>deletar(b.dataset.id)));
 out.querySelectorAll(".btn-pdf").forEach(b=>b.addEventListener("click",()=>gerarPdfPedido(b.dataset.id)));
}
function verDocumentoOS(id){const p=pedidos.find(x=>x.id===id);if(!p)return;const docs=Array.isArray(p.documentosOS)&&p.documentosOS.length?p.documentosOS:(p.documentoOS?[p.documentoOS]:[]);if(!docs.length)return;const w=window.open('','_blank');if(!w){alert('O navegador bloqueou a janela do documento. Permita pop-ups para esta extensão.');return}w.document.write(`<html><head><title>OS ${esc(p.os||'')}</title><style>body{margin:0;background:#111827;font-family:Arial;color:#fff;display:flex;flex-direction:column;align-items:center;gap:16px;padding:20px}img{max-width:92vw;max-height:90vh;object-fit:contain;background:#fff;box-shadow:0 8px 30px #0008}.t{font-weight:bold}</style></head><body><div class="t">OS ${esc(p.os||'Sem número')} — ${esc(p.cliente||'')}</div>${docs.map(x=>`<img src="${x}">`).join('')}</body></html>`);w.document.close()}

function fixarPedido(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;p.fixado=!p.fixado;PVStorage.set({pedidos},render);
}
function duplicarPedido(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 const agora=Date.now();const novo={...p,id:`pedido-${agora}-${Math.random().toString(36).slice(2,8)}`,os:"",status:"producao",criado:agora,entrada:new Date().toISOString().slice(0,10),fixado:false,historico:[{...eventoHistorico("Pedido duplicado",{status:"producao"}),t:agora}]};
 pedidos.push(novo);PVStorage.set({pedidos},()=>{render();alert(`Nova OS criada a partir de ${p.os||p.cliente}.`)});
}
function abrirHistorico(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;const h=Array.isArray(p.historico)?p.historico:[];
 $("#historicoTitulo").textContent=`Histórico — ${p.cliente}`;
 $("#historicoLista").innerHTML=h.length?h.slice().reverse().map(x=>`<div class="historico-item"><b>${esc(x.acao||"Alteração")}</b><small>${new Date(x.t||Date.now()).toLocaleString("pt-BR")}${x.responsavel?` · 👤 ${esc(x.responsavel)}`:""}</small>${x.alteracoes?.length?`<div class="historico-detalhes">${x.alteracoes.map(a=>`• ${esc(a)}`).join("<br>")}</div>`:""}</div>`).join(""):'<div class="vazio">Nenhum histórico.</div>';
 $("#historicoModal").classList.remove("oculto");
}
function arquivarPedido(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;if(!confirm(`Arquivar o pedido de ${p.cliente}?`))return;
 pedidos=pedidos.filter(x=>x.id!==id);PVStorage.get({arquivados:[]},x=>{const a=[{...p,arquivadoEm:Date.now()},...(x.arquivados||[])].slice(0,500);PVStorage.set({pedidos,arquivados:a},render)});
}
function abrirArquivados(){
 PVStorage.get({arquivados:[]},x=>{const a=x.arquivados||[];$("#arquivadosLista").innerHTML=a.length?a.map(p=>`<div class="lixeira-item"><div><b>${esc(p.cliente)}</b><br><small>${esc(pedidoResumoParaTela(p))} · ${p.os?`OS ${esc(p.os)}`:"sem OS"}</small></div><button class="btn-restaurar" data-id="${p.id}">↩ RESTAURAR</button></div>`).join(""):'<div class="vazio">Nenhum pedido arquivado.</div>';$("#arquivadosLista").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>restaurarArquivado(b.dataset.id)));$("#arquivadosModal").classList.remove("oculto")});
}
function restaurarArquivado(id){PVStorage.get({arquivados:[]},x=>{const a=x.arquivados||[],i=a.findIndex(p=>p.id===id);if(i<0)return;const {arquivadoEm,...p}=a[i];a.splice(i,1);pedidos.push(p);PVStorage.set({pedidos,arquivados:a},()=>{render();abrirArquivados()})})}
function irParaProxima(){const lista=pedidos.filter(p=>!finalizado(p)).sort(ordemLista);if(!lista.length){alert("Não há demandas pendentes.");return}const el=[...document.querySelectorAll("article.pedido")].find(x=>x.innerHTML.includes(`data-id="${lista[0].id}"`));if(el)el.scrollIntoView({behavior:"smooth",block:"center"});}
function autoBackupSemanal(){PVStorage.get({ultimoBackupAutomatico:0},x=>{if(Date.now()-(x.ultimoBackupAutomatico||0)<7*86400000)return;PVStorage.set({ultimoBackupAutomatico:Date.now()});exportarBackup();})}

function mudar(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 $("#statusModal").dataset.id=id;
 const ordem=["producao","impressao","acabamento","corte","laser","costura","estamparia","calandra","material","pronto","entregue","cancelado"];
 $("#statusModalTitulo").textContent=`Status de ${p.cliente}`;
 $("#statusModalLista").innerHTML=ordem.map(v=>`<button type="button" class="status-opcao ${v===p.status?"status-opcao-atual":""}" data-v="${v}">${STATUS[v]}${v===p.status?" ✓":""}</button>`).join("");
 $("#statusModalLista").querySelectorAll(".status-opcao").forEach(b=>b.addEventListener("click",()=>aplicarStatus(id,b.dataset.v)));
 $("#statusModal").classList.remove("oculto");
}
function fecharStatusModal(){$("#statusModal").classList.add("oculto")}
function aplicarStatus(id,novoStatus){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 const anterior=p.status;
 fecharStatusModal();
 if(novoStatus===anterior)return;
 p.status=novoStatus;
 if(!Array.isArray(p.historico))p.historico=[];
 p.historico.push(eventoHistorico(`Status: ${STATUS[novoStatus]||novoStatus}`,{de:anterior,status:novoStatus}));
 PVStorage.set({pedidos},()=>{render();avisarStatus(p,anterior);if(STATUS_PRODUCAO.has(p.status)&&!STATUS_PRODUCAO.has(anterior))avisarEntradaProducao(p);if(p.status==="pronto"&&anterior!=="pronto")avisarPronto(p);if(pagamentoPendente(p))avisarPagamentoPendente(p)});
}
function entregar(id){const p=pedidos.find(x=>x.id===id);if(!p)return;const anterior=p.status;p.status="entregue";
 if(!Array.isArray(p.historico))p.historico=[]; p.historico.push(eventoHistorico("Pedido entregue",{de:anterior,status:"entregue"}));PVStorage.set({pedidos},()=>{render();if(anterior!=="entregue")avisarStatus(p,anterior);if(pagamentoPendente(p))avisarPagamentoPendente(p)})}
function deletar(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 if(!confirm(`Excluir o pedido de ${p.cliente}?\n\nVai para a lixeira e pode ser restaurado por 15 dias.`))return;
 pedidos=pedidos.filter(x=>x.id!==id);
 PVStorage.get({lixeira:[]},x=>{
  const lixeira=[{...p,excluidoEm:Date.now()},...(x.lixeira||[])].slice(0,200);
  PVStorage.set({pedidos,lixeira},render);
 });
}
function abrirLixeira(){
 PVStorage.get({lixeira:[]},x=>{
  const limite=Date.now()-15*86400000;
  const lixeira=(x.lixeira||[]).filter(p=>(p.excluidoEm||0)>=limite);
  if(lixeira.length!==(x.lixeira||[]).length)PVStorage.set({lixeira});
  renderLixeira(lixeira);
  $("#lixeiraModal").classList.remove("oculto");
 });
}
function fecharLixeira(){$("#lixeiraModal").classList.add("oculto")}
function renderLixeira(lixeira){
 const box=$("#lixeiraLista");
 if(!lixeira.length){box.innerHTML='<div class="vazio">Lixeira vazia.</div>';return}
 box.innerHTML=lixeira.map(p=>{
  const dias=Math.max(0,15-Math.floor((Date.now()-(p.excluidoEm||0))/86400000));
  return `<div class="lixeira-item"><div><b>${esc(p.cliente)}</b><br><small>${esc(pedidoResumoParaTela(p))} · excluído há ${diasAtras(p.excluidoEm)} · some em ${dias} dia(s)</small></div><button type="button" class="btn-restaurar" data-id="${p.id}">↩ RESTAURAR</button></div>`;
 }).join("");
 box.querySelectorAll(".btn-restaurar").forEach(b=>b.addEventListener("click",()=>restaurarPedido(b.dataset.id)));
}
function diasAtras(t){const h=Math.floor((Date.now()-(t||0))/3600000);return h<1?"pouco tempo":h<24?`${h}h`:`${Math.floor(h/24)}d`}
function restaurarPedido(id){
 PVStorage.get({lixeira:[]},x=>{
  const lixeira=x.lixeira||[];
  const idx=lixeira.findIndex(p=>p.id===id);
  if(idx<0)return;
  const {excluidoEm,...p}=lixeira[idx];
  lixeira.splice(idx,1);
  pedidos.push(p);
  PVStorage.set({pedidos,lixeira},()=>{render();renderLixeira(lixeira)});
 });
}
function menuWhats(id){const p=pedidos.find(x=>x.id===id);if(!p)return;const op=prompt("Escolha a mensagem:\n\n1 = Em produção\n2 = Pedido pronto\n3 = Pode atrasar\n\nDigite 1, 2 ou 3:","2");if(!op)return;if(!["1","2","3"].includes(op)){alert("Escolha inválida. Use 1, 2 ou 3.");return}abrirWhats(p,op==="1"?"producao":op==="3"?"atraso":"pronto")}
async function copiarImagem(p){if(!p.imagemPedido)return false;try{const res=await fetch(p.imagemPedido);const blob=await res.blob();await navigator.clipboard.write([new ClipboardItem({[blob.type]:blob})]);return true}catch(e){return false}}
async function abrirWhats(p,tipo){
 const phone=String(p.telefone||'').replace(/\D/g,'');
 if(!phone){alert('O WhatsApp deste cliente não é válido.');return}
 const pedido=pedidoResumoParaTela(p);
 const itens=itensDoPedido(p);
 const listaItens=itens.map(x=>`• ${x.quantidade}x ${x.descricao||x.tipo||'item'}`).join('\n');
 const hora=p.horaMarcada?fmtDataHora(p.horaMarcada):'';
 const retirada=p.retirada||'';
 const tipoProduto=tiposItens(p);
 const endereco=enderecoResumo(p);
 const visita=p.retirada==='Empresa vai até o cliente'&&endereco;
 const logistica=visita?`📍 *Endereço da visita:* ${endereco}${p.endereco&&p.endereco.referencia?`
🔎 *Referência:* ${p.endereco.referencia}`:''}\n`:'';
 let msg='';
 if(tipo==='producao'){
   msg=`Olá, *${p.cliente}*! 👋\n\nSeu pedido já entrou em produção. 🏭\n\n📦 *Pedido:* ${pedido}\n${listaItens?`📦 *Itens:*\n${listaItens}\n`:''}${tipoProduto?`🧾 *Tipos:* ${tipoProduto}\n`:''}${p.prazo?`📅 *Prazo combinado:* ${br(p.prazo)}\n`:''}${hora?`⏰ *Hora combinada:* ${hora}\n`:''}${logistica}\nEstamos cuidando de cada etapa para deixar tudo pronto conforme combinado.\n\nAssim que finalizar, avisaremos você por aqui.\n\nObrigado pela confiança e preferência! 😊`;
 } else if(tipo==='pronto'){
   msg=`Olá, *${p.cliente}*! 🎉\n\nSeu pedido está *PRONTO*! ✅\n\n📦 *Pedido:* ${pedido}\n${listaItens?`📦 *Itens:*\n${listaItens}\n`:''}${tipoProduto?`🧾 *Tipos:* ${tipoProduto}\n`:''}${p.prazo?`📅 *Prazo combinado:* ${br(p.prazo)}\n`:''}${hora?`⏰ *Hora combinada:* ${hora}\n`:''}${retirada?`📍 *Retirada/atendimento:* ${retirada}\n`:''}${logistica}\nO pedido já está disponível para retirada em nossa loja. 🏪\n\nQuando estiver a caminho, pode nos avisar por aqui. 📲\n\nMuito obrigado pela confiança e preferência! 🙏`;
 } else {
   msg=`Olá, *${p.cliente}*! ⚠️\n\nPassando para avisar que o seu pedido de *${pedido}* pode sofrer um pequeno atraso.\n\n📦 *Pedido:* ${pedido}\n${p.prazo?`📅 *Prazo combinado:* ${br(p.prazo)}\n`:''}${hora?`⏰ *Hora combinada:* ${hora}\n`:''}${logistica}\nEstamos trabalhando para finalizar tudo o mais rápido possível e avisaremos você sobre qualquer atualização.\n\nPedimos desculpas pelo transtorno e agradecemos pela compreensão. 🙏`;
 }
 try{ const imgs=Array.isArray(p.imagensPedido)&&p.imagensPedido.length?p.imagensPedido:(p.imagemPedido?[p.imagemPedido]:[]); chrome.runtime.sendMessage({type:'ENVIAR_WHATS',phone,text:msg,imageData:imgs}); }
 catch(e){ alert('Não foi possível iniciar o WhatsApp.'); }
}
function avisarNovaDemanda(p){chrome.runtime.sendMessage({type:"NOVA_DEMANDA",cliente:p.cliente,pedido:p.pedido,os:p.os||"",prazo:p.prazo||""}).catch(()=>{})}
function avisarStatus(p,anterior){chrome.runtime.sendMessage({type:"STATUS_MUDOU",cliente:p.cliente,pedido:p.pedido,status:p.status,statusNome:STATUS[p.status]||"EM PRODUÇÃO",anterior:STATUS[anterior]||""}).catch(()=>{})}
function avisarEntradaProducao(p){chrome.runtime.sendMessage({type:"ENTRADA_PRODUCAO",cliente:p.cliente,pedido:p.pedido,setores:(p.setores||[]).join(", "),tipo:p.tipoProduto||""}).catch(()=>{})}
function avisarPronto(p){chrome.runtime.sendMessage({type:"PRODUCAO_PRONTA",cliente:p.cliente,pedido:p.pedido,hora:p.horaMarcada?fmtDataHora(p.horaMarcada):""}).catch(()=>{})}
function avisarPagamentoPendente(p){chrome.runtime.sendMessage({type:"PAGAMENTO_PENDENTE",cliente:p.cliente,pedido:p.pedido,statusNome:STATUS[p.status]||"",pagamento:nomePagamento(p.pagamentoStatus)}).catch(()=>{})}
async function gerarPdfPedido(id){const p=pedidos.find(x=>x.id===id);if(!p)return;const x=await PVStorage.get({empresa:{nome:"New Print Midia",logo:""},usuario:{nome:"",funcao:""}});const empresaPdf=Object.assign({},x.empresa||{}, {responsavel:(x.usuario||{}).nome||"",responsavelFuncao:(x.usuario||{}).funcao||""});await PDFUtil.gerar([p],empresaPdf,nomeArquivoPdf(p));}
async function gerarPdfGeral(){const q=$("#busca").value.toLowerCase(),f=$("#filtro").value,fd=$("#filtroData")?.value||"";const lista=pedidos.filter(p=>{const texto=`${p.cliente} ${p.telefone} ${p.pedido} ${p.os||""}`.toLowerCase();return(!q||texto.includes(q))&&(!f||(f==="atrasado"?(!finalizado(p)&&dias(p)<0):p.status===f))});if(!lista.length){alert("Não há pedidos para gerar o PDF.");return}const x=await PVStorage.get({empresa:{nome:"New Print Midia",logo:""},usuario:{nome:"",funcao:""}});const empresaPdf=Object.assign({},x.empresa||{}, {responsavel:(x.usuario||{}).nome||"",responsavelFuncao:(x.usuario||{}).funcao||""});await PDFUtil.gerar(lista,empresaPdf,`producao-${new Date().toISOString().slice(0,10)}.pdf`);}
function nomeArquivoPdf(p){const base=String(p.cliente||"pedido").replace(/[^a-z0-9à-ÿ]+/gi,"-").replace(/^-|-$/g,"");return `ordem-producao-${base||"pedido"}.pdf`}
function nomePagamento(x){return({nao_pago:"Não pago","50_pago":"50% pago",quitado:"Quitado",patrocinio:"Patrocínio do dono",personalizado:"Pagamento personalizado"})[x]||"Pagamento não informado"}
function nomePagamentoForma(x){return({pix:"Pix",especie:"Em espécie",cartao:"Cartão",especie_pix:"Espécie + Pix",pix_pix:"Pix + Pix",pix_cartao:"Pix + Cartão",especie_cartao:"Espécie + Cartão",patrocinio:"Patrocínio do dono",misto:"Outro / misto"})[x]||x||""}
function br(x){return x?String(x).split("-").reverse().join("/"):""}function fmtDataHora(x){return new Date(x).toLocaleString("pt-BR",{dateStyle:"short",timeStyle:"short"})}function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
/* ===== AVISOS FALADOS (VOZ) ===== */
const VOZ_PADRAO={ativa:true,voz:"",taxa:1,tom:.9,volume:1,falarNova:true,falarStatus:true,falarAtraso:true,falarPagamento:true,repetirAtraso:false,minutosRepetir:30};

function iniciarVoz(){
 preencherVozes();
 $("#testarVoz").addEventListener("click",()=>{
  PVStorage.set({vozConfig:lerFormVoz()},()=>{
   chrome.runtime.sendMessage({type:"TESTAR_VOZ",texto:"Atenção. Pedido de teste, cliente João da Silva, agora está na costura. Prazo para 20 de setembro."},r=>{
    if(chrome.runtime.lastError||!r||!r.ok)alert("Não consegui falar agora. Veja se o Windows tem vozes em português instaladas:\nConfigurações > Hora e idioma > Fala > Gerenciar vozes.");
   });
  });
 });
 $("#pararVoz").addEventListener("click",()=>{try{chrome.runtime.sendMessage({type:"PARAR_VOZ"})}catch(_){}});
 [["vozTaxa","vozTaxaVal",v=>Number(v).toFixed(2)],["vozTom","vozTomVal",v=>Number(v).toFixed(2)],["vozVolume","vozVolVal",v=>Math.round(v*100)+"%"]]
  .forEach(([id,alvo,fmt])=>$("#"+id).addEventListener("input",e=>{$("#"+alvo).textContent=fmt(e.target.value)}));
 $("#vozMinutos").addEventListener("input",e=>{$("#vozMinVal").textContent=e.target.value});
 $("#vozRepetir").addEventListener("change",e=>{$("#vozRepetirLinha").style.display=e.target.checked?"block":"none"});
}

function preencherVozes(){
 if(!chrome.tts||!chrome.tts.getVoices)return;
 chrome.tts.getVoices(vozes=>{
  const sel=$("#vozNome");const atual=sel.value;
  sel.innerHTML='<option value="">Automática (masculina em português)</option>';
  const pt=(vozes||[]).filter(v=>/^pt/i.test(v.lang||""));
  const outras=(vozes||[]).filter(v=>!/^pt/i.test(v.lang||""));
  const add=(lista,rotulo)=>{if(!lista.length)return;const g=document.createElement("optgroup");g.label=rotulo;
   lista.forEach(v=>{const o=document.createElement("option");o.value=v.voiceName;o.textContent=`${v.voiceName} (${v.lang||"?"})`;g.appendChild(o)});sel.appendChild(g)};
  add(pt,"Português");add(outras,"Outros idiomas");
  if(atual)sel.value=atual;
 });
}

function carregarFormVoz(){
 PVStorage.get({vozConfig:{}},x=>{
  const c={...VOZ_PADRAO,...(x.vozConfig||{})};
  $("#vozAtiva").checked=!!c.ativa;$("#vozNova").checked=!!c.falarNova;$("#vozStatus").checked=!!c.falarStatus;
  $("#vozAtraso").checked=!!c.falarAtraso;$("#vozPagamento").checked=!!c.falarPagamento;$("#vozRepetir").checked=!!c.repetirAtraso;
  $("#vozMinutos").value=c.minutosRepetir||30;$("#vozMinVal").textContent=c.minutosRepetir||30;$("#vozRepetirLinha").style.display=c.repetirAtraso?"block":"none";
  $("#vozTaxa").value=c.taxa;$("#vozTom").value=c.tom;$("#vozVolume").value=c.volume;
  $("#vozTaxaVal").textContent=Number(c.taxa).toFixed(2);$("#vozTomVal").textContent=Number(c.tom).toFixed(2);$("#vozVolVal").textContent=Math.round(c.volume*100)+"%";
  preencherVozes();setTimeout(()=>{$("#vozNome").value=c.voz||""},250);
 });
}

function lerFormVoz(){
 return{ativa:$("#vozAtiva").checked,voz:$("#vozNome").value||"",taxa:Number($("#vozTaxa").value)||1,tom:Number($("#vozTom").value)||1,volume:Number($("#vozVolume").value)||1,
  falarNova:$("#vozNova").checked,falarStatus:$("#vozStatus").checked,falarAtraso:$("#vozAtraso").checked,falarPagamento:$("#vozPagamento").checked,
  repetirAtraso:$("#vozRepetir").checked,minutosRepetir:Number($("#vozMinutos").value)||30};
}



// ==================== PENDÊNCIAS / BLOQUEIOS ====================
let pendenciaFiltroAtual='criticas';
function pendenciasDoPedido(p){return Array.isArray(p.pendencias)?p.pendencias:[]}
function pendenciaAtiva(p){return pendenciasDoPedido(p).filter(x=>x.ativa!==false)}
function totalPendenciasAtivas(){return pedidos.reduce((n,p)=>n+pendenciaAtiva(p).length,0)}
function abrirPendencias(){
 const m=$('#pendenciasModal');if(!m)return;m.classList.remove('oculto');renderPendencias(pendenciaFiltroAtual);
}
function fecharPendencias(){$('#pendenciasModal')?.classList.add('oculto')}
function abrirEditorPendencia(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 const m=$('#pendenciaEditorModal');if(!m)return;
 m.dataset.editId='';$('#pendenciaIdDemanda').value=id;
 $('#pendenciaEditorTitulo').textContent='⚠️ Registrar pendência';
 $('#pendenciaDemandaInfo').innerHTML=`<b>${esc(p.cliente||'Sem cliente')}</b> · ${esc(p.os?'OS '+p.os:pedidoResumoParaTela(p))}`;
 $('#pendenciaMotivo').value='';$('#pendenciaDescricao').value='';$('#pendenciaPrevisao').value='';$('#pendenciaBloqueia').checked=true;
 m.classList.remove('oculto');setTimeout(()=>$('#pendenciaDescricao')?.focus(),50);
}
function fecharEditorPendencia(){$('#pendenciaEditorModal')?.classList.add('oculto')}
function salvarPendencia(e){
 e.preventDefault();
 const id=$('#pendenciaIdDemanda').value,p=pedidos.find(x=>x.id===id);if(!p)return;
 const motivo=$('#pendenciaMotivo').value.trim(),descricao=$('#pendenciaDescricao').value.trim();
 if(!motivo){alert('Selecione o motivo do atraso/bloqueio.');return}
 if(!descricao){alert('Descreva o que aconteceu com a demanda.');return}
 if(!Array.isArray(p.pendencias))p.pendencias=[];
 const agora=Date.now();
 const item={id:`pend-${agora}-${Math.random().toString(36).slice(2,7)}`,t:agora,motivo,descricao,previsao:$('#pendenciaPrevisao').value||'',ativa:$('#pendenciaBloqueia').checked,resolvidaEm:null};
 p.pendencias.push(item);
 if(!Array.isArray(p.historico))p.historico=[];
 p.historico.push(eventoHistorico(`Pendência registrada: ${motivo}`,{pendencia:item.id,descricao})); item.responsavel=autorNota(); item.usuarioNome=usuarioAtual().nome; item.usuarioFuncao=usuarioAtual().funcao;
 PVStorage.set({pedidos},()=>{fecharEditorPendencia();render();if($('#pendenciasModal')&&!$('#pendenciasModal').classList.contains('oculto'))renderPendencias(pendenciaFiltroAtual);});
}
function resolverPendencia(idPedido,idPend){
 const p=pedidos.find(x=>x.id===idPedido);if(!p)return;const item=pendenciasDoPedido(p).find(x=>x.id===idPend);if(!item)return;
 item.ativa=false;item.resolvidaEm=Date.now();
 if(!Array.isArray(p.historico))p.historico=[];p.historico.push(eventoHistorico(`Pendência resolvida: ${item.motivo}`,{pendencia:item.id}));
 PVStorage.set({pedidos},()=>{render();renderPendencias(pendenciaFiltroAtual)});
}
function renderPendencias(filtro){
 pendenciaFiltroAtual=filtro||'criticas';
 const resumo=$('#pendenciasResumo'),lista=$('#pendenciasLista');if(!resumo||!lista)return;
 const atrasadas=pedidos.filter(p=>!finalizado(p)&&atrasado(p)).length;
 const risco=pedidos.filter(p=>!finalizado(p)&&vaiAtrasar(p)).length;
 const ativas=totalPendenciasAtivas();
 const material=pedidos.filter(p=>p.status==='material').length;
 const pagamento=pedidos.filter(pagamentoPendente).length;
 resumo.innerHTML=`<div class="pend-resumo-item red"><b>${atrasadas}</b><small>ATRASADAS</small></div><div class="pend-resumo-item orange"><b>${risco}</b><small>EM RISCO</small></div><div class="pend-resumo-item purple"><b>${ativas}</b><small>BLOQUEIOS ATIVOS</small></div><div class="pend-resumo-item blue"><b>${material}</b><small>MATERIAL</small></div><div class="pend-resumo-item green"><b>${pagamento}</b><small>PGTO PENDENTE</small></div>`;
 let rows=[];
 pedidos.forEach(p=>{
  const ps=pendenciasDoPedido(p);
  const ativos=ps.filter(x=>x.ativa!==false), todos=ps;
  let ok=false;
  if(filtro==='historico')ok=todos.length>0;
  else if(filtro==='material')ok=p.status==='material'||ativos.some(x=>/tecido|papel|tinta|material/i.test(x.motivo));
  else if(filtro==='pagamento')ok=pagamentoPendente(p)||ativos.some(x=>/pagamento/i.test(x.motivo));
  else if(filtro==='prazo')ok=!finalizado(p)&&(atrasado(p)||vaiAtrasar(p));
  else ok=ativos.length>0||(!finalizado(p)&&atrasado(p));
  if(!ok)return;
  const items=filtro==='historico'?todos:ativos;
  if(!items.length && (atrasado(p)||vaiAtrasar(p))){
   rows.push(`<div class="pend-row"><div><b>${esc(p.cliente)}</b><small>${esc(p.os?'OS '+p.os:pedidoResumoParaTela(p))} · ${atrasado(p)?'🔴 ATRASADA':'🟠 EM RISCO'}</small></div><button type="button" class="btn-pendencia" data-pid="${esc(p.id)}">⚠️ REGISTRAR MOTIVO</button></div>`);return;
  }
  items.slice().reverse().forEach(x=>rows.push(`<div class="pend-row"><div class="pend-row-main"><div><b>${esc(p.cliente)}</b> <span class="pend-motivo">${esc(x.motivo)}</span></div><small>${esc(p.os?'OS '+p.os:pedidoResumoParaTela(p))} · ${new Date(x.t).toLocaleString('pt-BR')}</small><p>${esc(x.descricao)}</p>${x.previsao?`<small>⏰ Previsão: ${esc(fmtDataHora(x.previsao))}</small>`:''}</div><div class="pend-row-actions">${x.ativa!==false?`<button type="button" class="btn-resolver-pend" data-pid="${esc(p.id)}" data-pend="${esc(x.id)}">✅ RESOLVIDA</button>`:'<span class="pend-resolvida">✓ RESOLVIDA</span>'}<button type="button" class="btn-pendencia" data-pid="${esc(p.id)}">＋ NOVA</button></div></div>`));
 });
 lista.innerHTML=rows.length?rows.join(''):'<div class="vazio">Nenhuma pendência encontrada.</div>';
 lista.querySelectorAll('.btn-pendencia').forEach(b=>b.addEventListener('click',()=>abrirEditorPendencia(b.dataset.pid)));
 lista.querySelectorAll('.btn-resolver-pend').forEach(b=>b.addEventListener('click',()=>resolverPendencia(b.dataset.pid,b.dataset.pend)));
}

// ==================== CALENDÁRIO DE PRODUÇÃO ====================
let calData=new Date();
let calSelecionado=dataKey(new Date());
function dataKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function dataLocal(key){const [y,m,d]=String(key||'').split('-').map(Number);return new Date(y||1970,(m||1)-1,d||1)}
function nomeDiaData(key){return dataLocal(key).toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'2-digit',year:'numeric'})}
function eventoDataDoPedido(p){
 const out=[];
 if(p.prazo)out.push({key:p.prazo,tipo:'prazo'});
 if(p.horaMarcada){const d=new Date(p.horaMarcada);if(!Number.isNaN(d.getTime()))out.push({key:dataKey(d),tipo:'hora',hora:d.toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})})}
 return out;
}
function pedidoPassaSetor(p){const s=$('#calSetor')?.value||'';return !s||Array.isArray(p.setores)&&p.setores.includes(s)}
function pedidosDoDia(key){return pedidos.filter(p=>!finalizado(p)||p.prazo===key||eventoDataDoPedido(p).some(e=>e.key===key)).filter(p=>pedidoPassaSetor(p)&&eventoDataDoPedido(p).some(e=>e.key===key))}
function classeEvento(p){if(atrasado(p))return 'red';if(vaiAtrasar(p))return 'orange';if(p.status==='pronto'||p.status==='entregue')return 'green';return 'blue'}
function tituloEvento(p,key){const ev=eventoDataDoPedido(p).filter(e=>e.key===key);const hora=ev.find(e=>e.tipo==='hora')?.hora;return `${hora?hora+' · ':''}${p.os?'OS '+p.os+' · ':''}${p.cliente||'Sem cliente'}`}
function abrirCalendario(){
 const m=$('#calendarioModal');if(!m)return;m.classList.remove('oculto');
 calData=new Date();calSelecionado=dataKey(new Date());renderCalendario();
}
function fecharCalendario(){$('#calendarioModal')?.classList.add('oculto')}
function moverCalendario(delta){calData=new Date(calData.getFullYear(),calData.getMonth()+delta,1);renderCalendario()}
function renderCalendario(){
 const grid=$('#calGrid');if(!grid)return;
 const y=calData.getFullYear(),m=calData.getMonth(),hoje=dataKey(new Date());
 $('#calTitulo').textContent=calData.toLocaleDateString('pt-BR',{month:'long',year:'numeric'}).replace(/^./,c=>c.toUpperCase());
 const primeiro=new Date(y,m,1);let inicio=(primeiro.getDay()+6)%7;
 const ultimo=new Date(y,m+1,0).getDate();const anteriorDias=new Date(y,m,0).getDate();
 let html='';
 for(let i=0;i<42;i++){
  const n=i-inicio+1;let key,day,cls='';
  if(n<1){day=anteriorDias+n;key=dataKey(new Date(y,m-1,day));cls='outro'}
  else if(n>ultimo){day=n-ultimo;key=dataKey(new Date(y,m+1,day));cls='outro'}
  else{day=n;key=dataKey(new Date(y,m,day))}
  if(key===hoje)cls+=' hoje';if(key===calSelecionado)cls+=' selecionado';
  const arr=pedidosDoDia(key);const max=3;
  const evs=arr.slice(0,max).map(p=>`<div class="cal-event ${classeEvento(p)}" data-id="${esc(p.id)}"><strong>${esc(tituloEvento(p,key))}</strong><small>${esc(STATUS[p.status]||'EM PRODUÇÃO')}${p.prazo===key?' · prazo':''}</small></div>`).join('');
  const more=arr.length>max?`<div class="cal-mais">+${arr.length-max} demanda(s)</div>`:'';
  html+=`<div class="cal-cell ${cls}" data-date="${key}"><div class="cal-num"><span>${day}</span>${arr.length?`<span class="cal-badge">${arr.length}</span>`:''}</div>${evs}${more}</div>`;
 }
 grid.innerHTML=html;
 grid.querySelectorAll('.cal-cell').forEach(c=>c.addEventListener('click',e=>{if(e.target.closest('.cal-event'))return;calSelecionado=c.dataset.date;const d=dataLocal(calSelecionado);if(d.getMonth()!==m||d.getFullYear()!==y)calData=new Date(d.getFullYear(),d.getMonth(),1);renderCalendario()}));
 grid.querySelectorAll('.cal-event').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();abrirDetalheCalendario(b.dataset.id)}));
 renderDiaCalendario(calSelecionado);
}
function renderDiaCalendario(key){
 const lista=$('#calDiaLista'),arr=pedidosDoDia(key),d=dataLocal(key);if(!lista)return;
 $('#calDiaTitulo').textContent=d.toLocaleDateString('pt-BR',{weekday:'short',day:'2-digit',month:'2-digit'}).replace('.','');
 $('#calDiaResumo').textContent=`${arr.length} ${arr.length===1?'demanda':'demandas'}`;
 if(!arr.length){lista.innerHTML='<div class="cal-vazio">Nenhuma demanda programada para este dia.</div>';return}
 lista.innerHTML=arr.sort((a,b)=>{
  const ah=a.horaMarcada&&dataKey(new Date(a.horaMarcada))===key?new Date(a.horaMarcada).getTime():a.prazo===key?8640000000000:0;
  const bh=b.horaMarcada&&dataKey(new Date(b.horaMarcada))===key?new Date(b.horaMarcada).getTime():b.prazo===key?8640000000000:0;
  return ah-bh;
 }).map(p=>{
   const ev=eventoDataDoPedido(p).filter(e=>e.key===key),h=ev.find(e=>e.tipo==='hora')?.hora;
   const status=STATUS[p.status]||'EM PRODUÇÃO';
   return `<div class="cal-dia-item" data-id="${esc(p.id)}"><div class="linha1"><strong>${esc(p.cliente||'Sem cliente')}</strong><span class="hora">${h?`⏰ ${h}`:(p.prazo===key?'📅 PRAZO':'')}</span></div><small>${esc(p.os?'OS '+p.os+' · ':'')}${esc(pedidoResumoParaTela(p))}</small><div class="setor">${(p.setores||[]).length?'🏭 '+esc(p.setores.join(' · ')):'🏭 Setor não informado'} · ${esc(status)}</div></div>`;
 }).join('');
 lista.querySelectorAll('.cal-dia-item').forEach(x=>x.addEventListener('click',()=>abrirDetalheCalendario(x.dataset.id)));
}
function fecharCalDetalhe(){$('#calDetalheModal')?.classList.add('oculto')}
function abrirDetalheCalendario(id){
 const p=pedidos.find(x=>x.id===id);if(!p)return;
 const m=$('#calDetalheModal'),box=$('#calDetalheConteudo');if(!m||!box)return;
 m.dataset.id=id;
 const limite=limitePedido(p);
 const prazo=p.prazo?br(p.prazo):'—';
 const hora=p.horaMarcada?fmtDataHora(p.horaMarcada):'—';
 const setor=Array.isArray(p.setores)&&p.setores.length?p.setores.join(' · '):'Não informado';
 const status=STATUS[p.status]||'EM PRODUÇÃO';
 const pagamento=p.pagamentoStatus||'Não informado';
 box.innerHTML=`<div class="cal-detalhe-titulo"><strong>${esc(p.cliente||'Sem cliente')}</strong><span class="badge ${estado(p)[0]}">${esc(estado(p)[1])}</span></div>
 <div class="cal-detalhe-grid">
  <div><small>OS</small><b>${esc(p.os||'Sem OS')}</b></div>
  <div><small>Pedido</small><b>${esc(pedidoResumoParaTela(p)||'—')}</b></div>
  <div><small>Prazo</small><b>📅 ${esc(prazo)}</b></div>
  <div><small>Hora marcada</small><b>⏰ ${esc(hora)}</b></div>
  <div><small>Setor</small><b>🏭 ${esc(setor)}</b></div>
  <div><small>Pagamento</small><b>💰 ${esc(pagamento)}</b></div>
 </div>
 ${p.observacoes?`<div class="cal-detalhe-obs"><small>Observações</small><p>${esc(p.observacoes)}</p></div>`:''}`;
 m.classList.remove('oculto');
} 

init();

/* RELÓGIO PC / ALERTA CIRÚRGICO
   O painel lê Date() diretamente do Windows. A cada 100 ms atualiza o relógio
   e, na virada do segundo, pede ao service worker uma verificação imediata.
*/
function atualizarRelogioPC(){
 const agora=new Date();
 $("#horaPC").textContent=agora.toLocaleTimeString("pt-BR",{hour12:false});
 $("#dataPC").textContent=agora.toLocaleDateString("pt-BR");
 render();
}
let ultimoSegundoPC=-1;
setInterval(()=>{
 const agora=new Date();
 const sec=agora.getSeconds();
 $("#horaPC").textContent=agora.toLocaleTimeString("pt-BR",{hour12:false});
 $("#dataPC").textContent=agora.toLocaleDateString("pt-BR");
 if(sec!==ultimoSegundoPC){
   ultimoSegundoPC=sec;
   render();
   try{chrome.runtime.sendMessage({type:"CHECK_CLOCK_NOW",now:agora.getTime()});}catch(_){}
 }
},100);

window.PVBridge={storage:PVStorage,orders:()=>pedidos,async apply(list,trash,archived){pedidos=list;render();await PVStorage.set({pedidos:list,lixeira:trash,...(archived?{arquivados:archived}:{})},null,"remote")},setSectors(rows){const first=document.querySelector("#primeiroSetor");if(first){const value=first.value;first.innerHTML='<option value="">Primeiro setor selecionado</option>'+rows.map(s=>'<option value="'+esc(s.codigo)+'">'+esc(s.nome)+'</option>').join('');first.value=value;}const grid=document.querySelector('.setores-grid');if(!grid)return;const checked=new Set([...grid.querySelectorAll('input:checked')].map(x=>x.value));grid.innerHTML=rows.map(s=>'<label><input type="checkbox" name="setor" value="'+esc(s.nome)+'" '+(checked.has(s.nome)?'checked':'')+'> '+esc(s.nome)+'</label>').join('');const sel=document.querySelector('#calSetor');if(sel){const old=sel.value;sel.innerHTML='<option value="">Todos os setores</option>'+rows.map(s=>'<option>'+esc(s.nome)+'</option>').join('');sel.value=old}}};
