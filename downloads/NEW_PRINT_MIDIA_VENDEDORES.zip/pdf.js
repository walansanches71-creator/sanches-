/* New Print Midia — PDF profissional de Ordem de Produção
   Gerado com jsPDF (vendor/jspdf.umd.min.js), embutido localmente na extensão.
   Mantém a mesma API pública usada pelo painel.js: PDFUtil.gerar(pedidos, empresa, filename)
*/
const PDFUtil = {
  async gerar(pedidos, empresa, filename) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'pt', format: 'a4', compress: true });

    const e = Object.assign({}, empresa || {});
    let logo = null;
    if (e.logo) {
      const jpeg = await toJpeg(e.logo, 480, 0.92);
      const size = await imgSize(jpeg);
      if (size) logo = Object.assign({ data: jpeg }, size);
    }

    const lista = Array.isArray(pedidos) ? pedidos : [];
    let primeiro = true;
    for (const original of lista) {
      const p = Object.assign({}, original);
      const refsOriginais = Array.isArray(p.imagensPedido) && p.imagensPedido.length
        ? p.imagensPedido
        : (p.imagemPedido ? [p.imagemPedido] : []);
      const docsOriginais = Array.isArray(p.documentosOS) && p.documentosOS.length ? p.documentosOS : (p.documentoOS ? [p.documentoOS] : []);
      const docsOS = [];
      for (const src of docsOriginais.slice(0, 2)) { const jpeg = await toJpegDocumento(src, 2400, 0.96); const size = await imgSize(jpeg); if (size) docsOS.push(Object.assign({data: jpeg}, size)); }
      const refs = [];
      for (const src of refsOriginais.slice(0, 12)) {
        const jpeg = await toJpeg(src, 1100, 0.84);
        const size = await imgSize(jpeg);
        if (size) refs.push(Object.assign({ data: jpeg }, size));
      }
      if (!primeiro) doc.addPage();
      primeiro = false;
      renderPaginaPedido(doc, p, e, logo, refs, docsOS);
    }

    desenharRodapes(doc, e, 'Ordem de produção');
    doc.save(filename || 'ordem-producao.pdf');
  },

  /* Relatório gerencial em formato de dashboard.
     dados = { titulo, subtitulo, kpis:[{label,valor,cor}], atrasos:[{cliente,os,resumo,un,prazo,status,atraso}],
               grupos:[{titulo, cor, dados:[[rotulo,valor],...]}] } */
  async relatorio(dados, empresa, filename) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'pt', format: 'a4', compress: true });
    const e = Object.assign({}, empresa || {});
    let logo = null;
    if (e.logo) {
      const jpeg = await toJpeg(e.logo, 480, 0.92);
      const size = await imgSize(jpeg);
      if (size) logo = Object.assign({ data: jpeg }, size);
    }
    renderRelatorioPdf(doc, dados || {}, e, logo);
    desenharRodapes(doc, e, 'Relatório de produção');
    doc.save(filename || 'relatorio-producao.pdf');
  }
};

/* ===== Preparo de imagens (preserva proporção — não força quadrado) ===== */
async function toJpeg(dataUrl, maxSide = 1400, quality = .86) {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) return dataUrl;
  try {
    const img = await new Promise((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = reject;
      i.src = dataUrl;
    });
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    const scale = Math.min(1, maxSide / Math.max(w0, h0));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w0 * scale));
    c.height = Math.max(1, Math.round(h0 * scale));
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, c.width, c.height);
    ctx.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', quality);
  } catch (err) { return dataUrl; }
}
async function toJpegDocumento(dataUrl, maxSide = 2400, quality = .96) {
  if (!dataUrl || !dataUrl.startsWith('data:image/')) return dataUrl;
  try {
    const img = await new Promise((resolve, reject) => {
      const i = new Image(); i.onload = () => resolve(i); i.onerror = reject; i.src = dataUrl;
    });
    const w0 = img.naturalWidth || img.width, h0 = img.naturalHeight || img.height;
    const scale = Math.min(1, maxSide / Math.max(w0, h0));
    const c0 = document.createElement('canvas'); c0.width = Math.max(1, Math.round(w0 * scale)); c0.height = Math.max(1, Math.round(h0 * scale));
    const ctx0 = c0.getContext('2d', {willReadFrequently:true});
    ctx0.fillStyle = '#fff'; ctx0.fillRect(0,0,c0.width,c0.height); ctx0.drawImage(img,0,0,c0.width,c0.height);
    const data = ctx0.getImageData(0,0,c0.width,c0.height).data;
    let minX=c0.width,minY=c0.height,maxX=-1,maxY=-1;
    for(let y=0;y<c0.height;y++) for(let x=0;x<c0.width;x++) {
      const k=(y*c0.width+x)*4, r=data[k], g=data[k+1], b=data[k+2], a=data[k+3];
      if(a>10 && (r<242 || g<242 || b<242)) { if(x<minX)minX=x; if(y<minY)minY=y; if(x>maxX)maxX=x; if(y>maxY)maxY=y; }
    }
    if(maxX<0) return c0.toDataURL('image/jpeg',quality);
    const pad = Math.max(4, Math.round(Math.min(c0.width,c0.height)*0.012));
    minX=Math.max(0,minX-pad); minY=Math.max(0,minY-pad); maxX=Math.min(c0.width-1,maxX+pad); maxY=Math.min(c0.height-1,maxY+pad);
    const c=document.createElement('canvas'); c.width=maxX-minX+1; c.height=maxY-minY+1;
    const ctx=c.getContext('2d'); ctx.fillStyle='#fff'; ctx.fillRect(0,0,c.width,c.height); ctx.drawImage(c0,minX,minY,c.width,c.height,0,0,c.width,c.height);
    return c.toDataURL('image/jpeg',quality);
  } catch(err) { return dataUrl; }
}
function imgSize(dataUrl) {
  return new Promise((resolve) => {
    if (!dataUrl) { resolve(null); return; }
    const img = new Image();
    img.onload = () => resolve({ w: img.naturalWidth || img.width, h: img.naturalHeight || img.height });
    img.onerror = () => resolve(null);
    img.src = dataUrl;
  });
}

/* ===== Paleta e layout ===== */
const COR = {
  blue: [26, 92, 219], blueDark: [16, 62, 158], dark: [20, 31, 51], muted: [87, 102, 125], white: [255, 255, 255],
  green: [15, 140, 82], red: [199, 31, 31], orange: [245, 115, 20], purple: [111, 66, 193],
  fieldBg: [245, 247, 252], obsBg: [250, 250, 252], line: [220, 226, 238], tint: [219, 232, 255]
};
const PAGE = { W: 595.28, H: 841.89, margin: 28 };
const RODAPE_RESERVA = 34;

function novoEstado(e) {
  return { W: PAGE.W, H: PAGE.H, margin: PAGE.margin, y: 0, empresa: e };
}
function ensureSpace(doc, state, p, needed) {
  if (state.y + needed > state.H - state.margin - RODAPE_RESERVA + 10) {
    doc.addPage();
    drawContinuationHeader(doc, state, p);
  }
}
/* Rodapé com "Página X de Y" — desenhado no fim, quando já se sabe o total de páginas. */
function desenharRodapes(doc, e, rotulo) {
  const total = doc.internal.getNumberOfPages();
  const W = PAGE.W, H = PAGE.H, m = PAGE.margin;
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    doc.setDrawColor(...COR.line); doc.setLineWidth(0.6); doc.line(m, H - 34, W - m, H - 34);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...COR.muted);
    doc.text(`${(e && e.nome) || 'New Print Midia'} • ${rotulo} • gerado em ${new Date().toLocaleString('pt-BR')}`, m, H - 20);
    doc.setFont('helvetica', 'bold');
    doc.text(`Página ${i} de ${total}`, W - m, H - 20, { align: 'right' });
  }
}
function osRotulo(p) { const o = String(p.os || '').trim(); if (!o) return 'SEM Nº DE OS'; return /^os\b/i.test(o) ? o : `OS ${o}`; }
function drawContinuationHeader(doc, state, p) {
  doc.setFillColor(...COR.blue); doc.rect(0, 0, state.W, 44, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(...COR.white);
  const titulo = `${p.cliente || ''} · ${p.pedido || resumoItensPDF(p) || 'Demanda'}`;
  const dir = `${osRotulo(p)} (continuação)`;
  doc.setFontSize(8.5);
  const wDir = doc.getTextWidth(dir);
  doc.setFontSize(12);
  doc.text(doc.splitTextToSize(titulo, state.W - 2 * state.margin - wDir - 16)[0], state.margin, 28);
  doc.setFontSize(10);
  doc.text(dir, state.W - state.margin, 28, { align: 'right' });
  state.y = 62;
}

/* Título de seção padronizado: barra colorida + texto + régua */
function drawSecao(doc, state, titulo, extra, x0, w0) {
  const margin = x0 === undefined ? state.margin : x0;
  const largura = w0 === undefined ? state.W - 2 * state.margin : w0;
  doc.setFillColor(...COR.blue); doc.rect(margin, state.y, 4, 15, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(...COR.dark);
  doc.text(String(titulo).toUpperCase(), margin + 11, state.y + 12);
  if (extra) {
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...COR.muted);
    doc.text(String(extra), margin + largura, state.y + 12, { align: 'right' });
  }
  doc.setDrawColor(...COR.line); doc.setLineWidth(0.8); doc.line(margin, state.y + 20, margin + largura, state.y + 20);
  state.y += 24;
}


// Desenha uma imagem contida (sem esticar) dentro de uma caixa.
function caixaImagem(doc, info, x, y, w, h, rotulo) {
  doc.setFillColor(...COR.fieldBg); doc.setDrawColor(...COR.line); doc.setLineWidth(0.6);
  doc.roundedRect(x, y, w, h, 6, 6, 'FD');
  const pad = 8, maxW = w - 2 * pad, maxH = h - 2 * pad;
  const escala = Math.min(maxW / info.w, maxH / info.h);
  const iw = info.w * escala, ih = info.h * escala;
  try { doc.addImage(info.data, 'JPEG', x + (w - iw) / 2, y + (h - ih) / 2, iw, ih); } catch (err) {}
  if (rotulo) {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8); doc.setTextColor(...COR.muted);
    doc.text(rotulo, x + w - 8, y + h - 6, { align: 'right' });
  }
}

/* ===== Cabeçalho grande + OS em destaque ===== */
function drawCabecalho(doc, state, e, logo, p, compacto = false) {
  const { W, margin } = state;
  // Cabeçalho ultracompacto para manter a OS inteira em uma única página.
  // Não altera a proporção nem o conteúdo das imagens/documentos.
  const H = compacto ? 54 : 72;
  doc.setFillColor(...COR.blue); doc.rect(0, 0, W, H, 'F');
  doc.setFillColor(...COR.blueDark); doc.rect(0, H - 3, W, 3, 'F');

  let textX = margin;
  if (logo && logo.data && logo.w && logo.h) {
    const maxW = compacto ? 72 : 92, maxH = compacto ? 34 : 42;
    const escala = Math.min(maxW / logo.w, maxH / logo.h, 1);
    const iw = logo.w * escala, ih = logo.h * escala;
    doc.setFillColor(...COR.white); doc.roundedRect(margin, compacto ? 7 : 9, iw + 10, ih + 10, 4, 4, 'F');
    try { doc.addImage(logo.data, 'JPEG', margin + 5, compacto ? 12 : 14, iw, ih); textX = margin + iw + 17; }
    catch (err) { textX = margin; }
  }

  doc.setFont('helvetica', 'bold'); doc.setFontSize(compacto ? 16 : 19); doc.setTextColor(...COR.white);
  const nome = doc.splitTextToSize(e.nome || 'New Print Midia', W - textX - margin - 118)[0];
  doc.text(nome, textX, compacto ? 25 : 32);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(compacto ? 7.5 : 9); doc.setTextColor(...COR.tint);
  doc.text('ORDEM DE PRODUÇÃO', textX, compacto ? 38 : 45);

  const bw = compacto ? 92 : 108, bh = compacto ? 38 : 46, bx = W - margin - bw;
  const by = compacto ? 8 : 10;
  doc.setFillColor(...COR.white); doc.roundedRect(bx, by, bw, bh, 5, 5, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(6.5); doc.setTextColor(...COR.muted);
  doc.text('Nº DA OS', bx + bw / 2, by + 12, { align: 'center' });
  const os = String(p.os || 'SEM OS');
  let fs = compacto ? 18 : 21; doc.setFontSize(fs);
  while (fs > 11 && doc.getTextWidth(os) > bw - 12) { fs -= 1; doc.setFontSize(fs); }
  doc.setTextColor(...COR.blue);
  doc.text(os, bx + bw / 2, by + 31, { align: 'center' });

  state.y = H + 7;
  const st = statusPDF(p.status);
  const stColor = st === 'ATRASADO' ? COR.red : (['PRONTO', 'ENTREGUE'].includes(st) ? COR.green : (st === 'CANCELADO' ? COR.muted : COR.blue));
  const sh = compacto ? 22 : 25;
  doc.setFillColor(...stColor); doc.roundedRect(margin, state.y, W - 2 * margin, sh, 4, 4, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(compacto ? 9.5 : 10.5); doc.setTextColor(...COR.white);
  doc.text(`STATUS: ${st}`, margin + 10, state.y + 15);
  doc.text(`PRIORIDADE: ${String(p.prioridade || 'Normal').toUpperCase()}`, W - margin - 10, state.y + 15, { align: 'right' });
  state.y += sh + 7;
}

function drawResponsavel(doc, state, responsavel) {
  const { W, margin } = state;
  const areaW = W - 2 * margin;
  const h = 24;
  const texto = String(responsavel || 'Não informado').trim() || 'Não informado';
  doc.setFillColor(...COR.fieldBg);
  doc.setDrawColor(...COR.line);
  doc.setLineWidth(0.6);
  doc.roundedRect(margin, state.y, areaW, h, 5, 5, 'FD');
  doc.setFillColor(...COR.blue);
  doc.roundedRect(margin, state.y, 5, h, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(...COR.muted);
  doc.text('RESPONSÁVEL PELA DEMANDA', margin + 12, state.y + 9);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(...COR.dark);
  const linhas = doc.splitTextToSize(texto, areaW - 190).slice(0, 1);
  doc.text(linhas[0] || 'Não informado', margin + 170, state.y + 16);
  state.y += h + 6;
}

function itensPDF(p){
  const arr=Array.isArray(p&&p.itens)?p.itens:[];
  if(arr.length) return arr.map((x,i)=>({n:i+1,tipo:String(x.tipo||''),descricao:String(x.descricao||x.nome||x.item||''),quantidade:Math.max(1,Number(x.quantidade)||1)}));
  if(p&&(p.pedido||p.tipoProduto||p.quantidade)) return [{n:1,tipo:String(p.tipoProduto||''),descricao:String(p.pedido||''),quantidade:Math.max(1,Number(p.quantidade)||1)}];
  return [];
}
function resumoItensPDF(p){return itensPDF(p).map(x=>`${x.quantidade}x ${x.descricao||x.tipo||'item'}`).join(' · ');}

function renderPaginaPedido(doc, p, e, logo, refs, docsOS) {
  const state = novoEstado(e);
  const { W, margin } = state;
  const areaW = W - 2 * margin;
  const bottom = state.H - 38;
  const cabCompacto = ((refs && refs.length > 1) || (docsOS && docsOS.length > 1));
  drawCabecalho(doc, state, e, logo, p, cabCompacto);
  const responsavel = p.responsavelDemanda || ((e.responsavel || "").trim() ? `${e.responsavel.trim()}${e.responsavelFuncao ? ` — ${e.responsavelFuncao.trim()}` : ""}` : "Não informado");
  drawResponsavel(doc, state, responsavel);
  drawItensCompactos(doc, state, p);

  const temDoc = !!(docsOS && docsOS.length);
  const lateral = temDoc && refs.length > 0;      // nota grande em cima; dados à esquerda e referências à direita
  const REFW = 250, GAP = 12;
  const dados = lateral ? planejarDados(doc, state, p, areaW - REFW - GAP, 2, responsavel) : planejarDados(doc, state, p, undefined, undefined, responsavel);

  // Observações: quantas linhas couberem, preservando espaço para a nota/imagens.
  doc.setFont('helvetica', 'normal'); doc.setFontSize(10);
  const obsW = lateral ? areaW - REFW - GAP : areaW;
  const obsTodas = doc.splitTextToSize(p.observacoes || 'Sem observações.', obsW - 24);
  const LH = 12.5;
  let obsLinhas = obsTodas;
  const obsH = 28 + Math.min(obsLinhas.length,14) * LH + 16 + 8;
  // A OS vem antes dos dados e deve usar o máximo da largura disponível.
  // Não reservamos previamente o espaço dos blocos que serão desenhados depois;
  // isso fazia a imagem ser comprimida dentro de uma caixa baixa.
  const avail = temDoc ? (bottom - state.y - 24) : (bottom - state.y - dados.h - obsH);

  if (temDoc) {
    // NOTA/OS: caixa mais alta para a proporção natural da imagem ocupar
    // praticamente toda a largura da página, sem deformar o documento.
    const planDoc = planejarGrade(docsOS, areaW, docsOS.length > 1 ? 2 : 1, 900);
    let hDoc = planDoc.total;
    if (docsOS.length === 1 && docsOS[0] && docsOS[0].w && docsOS[0].h) {
      const larguraUtil = areaW - 16;
      const alturaNatural = larguraUtil * (docsOS[0].h / docsOS[0].w) + 18;
      hDoc = Math.max(hDoc, Math.min(320, Math.max(260, alturaNatural)));
    }
    hDoc = Math.max(80, Math.min(hDoc, Math.max(80, avail)));
    drawSecao(doc, state, 'Documento / OS liberada', osRotulo(p));
    drawGrade(doc, state, docsOS, planDoc, hDoc, areaW);
    state.y += 12;
  } else {
    const planRef = planejarGrade(refs, areaW, refs.length <= 1 ? 1 : (refs.length === 2 ? 2 : 3), 270);
    const hRef = Math.max(60, Math.min(planRef.total, avail - 28 - 12));
    drawSecao(doc, state, refs.length > 1 ? 'Referências visuais' : 'Referência principal', refs.length > 1 ? `${refs.length} imagens` : '');
    if (!refs.length) {
      doc.setFillColor(...COR.fieldBg); doc.roundedRect(margin, state.y, areaW, 40, 6, 6, 'F');
      doc.setFont('helvetica', 'normal'); doc.setFontSize(11); doc.setTextColor(...COR.muted);
      doc.text('Sem imagem / referência anexada', margin + 16, state.y + 24);
      state.y += 40 + 12;
    } else { drawGrade(doc, state, refs, planRef, hRef, areaW); state.y += 12; }
  }

  // Dados + observações na coluna esquerda; referência ocupa a coluna direita inteira.
  const yDados = state.y;
  drawDadosCompactos(doc, state, dados);

  drawSecao(doc, state, 'Especificações e observações', '', margin, obsW);
  const cabem = Math.max(1, Math.floor((bottom - state.y - 24) / LH));
  const obsRestantes = obsLinhas.slice(cabem);
  obsLinhas = obsLinhas.slice(0, cabem);
  const boxH = obsLinhas.length * LH + 16;
  doc.setFillColor(...COR.obsBg); doc.setDrawColor(...COR.line); doc.setLineWidth(0.6);
  doc.roundedRect(margin, state.y, obsW, boxH, 5, 5, 'FD');
  doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(...COR.dark);
  obsLinhas.forEach((ln, i) => doc.text(ln, margin + 12, state.y + 17 + i * LH));
  state.y += boxH + 8;
  const yFim = state.y;

  if (lateral) {
    const rx = margin + areaW - REFW;
    const st2 = { y: yDados };
    drawSecao(doc, st2, refs.length > 1 ? 'Referências' : 'Referência', refs.length > 1 ? `${refs.length}` : '', rx, REFW);
    const hBox = Math.max(60, yFim - 8 - st2.y);
    const cols = refs.length <= 1 ? 1 : (refs.length <= 4 ? 2 : 3);
    const g = 6, cw = (REFW - g * (cols - 1)) / cols, rows = Math.ceil(refs.length / cols), ch = (hBox - g * (rows - 1)) / rows;
    refs.forEach((img, i) => caixaImagem(doc, img, rx + (i % cols) * (cw + g), st2.y + Math.floor(i / cols) * (ch + g), cw, ch, refs.length > 1 ? `${i + 1}/${refs.length}` : ''));
  }
  // Only overflowing observations continue; the existing first-page design stays intact.
  while(obsRestantes.length){
    doc.addPage();const next=novoEstado(e);drawCabecalho(doc,next,e,logo,p,true);
    drawSecao(doc,next,'Especificações e observações - continuação');
    const count=Math.max(1,Math.floor((bottom-next.y-24)/LH)),lines=obsRestantes.splice(0,count);
    doc.setFont('helvetica','normal');doc.setFontSize(10);doc.setTextColor(...COR.dark);
    lines.forEach((line,i)=>doc.text(line,margin+12,next.y+17+i*LH));
  }
}

/* ===== Imagens: planejamento e desenho em grade (contain, sem esticar) ===== */
function planejarGrade(imgs, areaW, cols, cap) {
  if (!imgs.length) return { cols, rows: 0, cellW: areaW, total: 0 };
  const gap = 12, cellW = (areaW - gap * (cols - 1)) / cols;
  const rows = Math.ceil(imgs.length / cols);
  const cellH = Math.min(cap, Math.max(...imgs.map(i => cellW * i.h / i.w)) + 16);
  return { cols, rows, cellW, gap, cellH, total: rows * cellH + (rows - 1) * 10 };
}
function drawGrade(doc, state, imgs, plan, totalH, areaW) {
  const { margin } = state;
  const cellH = Math.max(28, (totalH - (plan.rows - 1) * 10) / plan.rows);
  for (let r = 0; r < plan.rows; r++) {
    for (let c = 0; c < plan.cols; c++) {
      const i = r * plan.cols + c; if (i >= imgs.length) break;
      caixaImagem(doc, imgs[i], margin + c * (plan.cellW + plan.gap), state.y, plan.cellW, cellH, imgs.length > 1 ? `${i + 1}/${imgs.length}` : '');
    }
    state.y += cellH + (r < plan.rows - 1 ? 10 : 0);
  }
}

/* ===== Itens da demanda — bloco compacto logo abaixo do status ===== */
function drawItensCompactos(doc, state, p) {
  const { W, margin } = state, areaW = W - 2 * margin;
  const items = itensPDF(p);
  if (!items.length) return;
  const MAX = 6, mostrar = items.slice(0, MAX), extra = items.length - mostrar.length;
  const totalUn = items.reduce((n, x) => n + x.quantidade, 0);
  drawSecao(doc, state, 'Itens da demanda', `${totalUn} unidade(s) · ${items.length} item(ns)`);
  const cN = 26, cT = 120, cQ = 50, cP = areaW - cN - cT - cQ;
  doc.setFillColor(...COR.dark); doc.roundedRect(margin, state.y, areaW, 17, 4, 4, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(...COR.white);
  doc.text('#', margin + cN / 2, state.y + 12, { align: 'center' });
  doc.text('PRODUTO / DESCRIÇÃO', margin + cN + 6, state.y + 12);
  doc.text('TIPO', margin + cN + cP + 6, state.y + 12);
  doc.text('QTD.', margin + areaW - cQ / 2, state.y + 12, { align: 'center' });
  state.y += 19;
  mostrar.forEach((it, idx) => {
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
    const linhas = doc.splitTextToSize(it.descricao || it.tipo || 'Item', cP - 12).slice(0, 2);
    const rowH = linhas.length > 1 ? 26 : 18;
    doc.setFillColor(...(idx % 2 ? [250, 251, 253] : COR.fieldBg)); doc.roundedRect(margin, state.y, areaW, rowH, 3, 3, 'F');
    doc.setTextColor(...COR.muted); doc.text(String(idx + 1), margin + cN / 2, state.y + rowH / 2 + 3, { align: 'center' });
    doc.setTextColor(...COR.dark);
    linhas.forEach((ln, i) => doc.text(ln, margin + cN + 6, state.y + 12 + i * 10));
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...COR.muted);
    doc.text(doc.splitTextToSize(it.tipo || '', cT - 10).slice(0, 2), margin + cN + cP + 6, state.y + (linhas.length > 1 ? 14 : 14));
    doc.setFont('helvetica', 'bold'); doc.setFontSize(13); doc.setTextColor(...COR.blue);
    doc.text(String(it.quantidade), margin + areaW - cQ / 2, state.y + rowH / 2 + 4, { align: 'center' });
    state.y += rowH + 2;
  });
  if (extra > 0) {
    doc.setFont('helvetica', 'italic'); doc.setFontSize(9); doc.setTextColor(...COR.muted);
    doc.text(`+ ${extra} item(ns) não exibido(s) neste resumo`, margin + 6, state.y + 10);
    state.y += 14;
  }
  state.y += 4;
}

/* ===== Dados da demanda — 3 colunas, abaixo das imagens ===== */
function planejarDados(doc, state, p, largura, cols, responsavel) {
  const { W, margin } = state; largura = largura || (W - 2 * margin); cols = cols || 3;
  const gap = 6, w = (largura - gap * (cols - 1)) / cols;
  const campos = [
    ['Cliente', p.cliente], ['WhatsApp', p.telefone], ['Retirada / atendimento', p.retirada || 'Não informado'],
    ['Entrada', brPDF(p.entrada)], ['Prazo de entrega', brPDF(p.prazo)], ['Hora combinada', p.horaMarcada ? fmtPDF(p.horaMarcada) : 'Não informada'],
    ['Pagamento', pagamentoResumoPDF(p)], ['Setores envolvidos', (p.setores && p.setores.length) ? p.setores.join(' · ') : 'Não informado'],
    ['Responsável pela demanda', responsavel || 'Não informado']
  ];
  doc.setFont('helvetica', 'bold'); doc.setFontSize(10);
  const cel = campos.map(c => ({ label: c[0], linhas: doc.splitTextToSize(String(c[1] || '-'), w - 18).slice(0, 2), acc: COR.blue }));
  const linhasGrid = [];
  for (let i = 0; i < cel.length; i += cols) {
    const par = cel.slice(i, i + cols);
    linhasGrid.push({ par, h: 14 + Math.max(...par.map(x => x.linhas.length)) * 10 + 4 });
  }
  const extras = [];
  if (p.pagamentoDetalhes) extras.push(['Detalhes do pagamento', p.pagamentoDetalhes]);
  const end = enderecoPDF(p);
  if (end && end !== '-') extras.push(['Endereço / local de atendimento', end]);
  const ex = extras.map(([label, v]) => { const l = doc.splitTextToSize(String(v), largura - 18).slice(0, 2); return { label, linhas: l, acc: COR.orange, h: 14 + l.length * 10 + 4 }; });
  const h = 28 + linhasGrid.reduce((n, r) => n + r.h + 3, 0) + ex.reduce((n, r) => n + r.h + 3, 0) + 4;
  return { linhasGrid, ex, w, gap, h, largura };
}
function drawDadosCompactos(doc, state, d) {
  const { margin } = state;
  drawSecao(doc, state, 'Dados da demanda', '', margin, d.largura);
  d.linhasGrid.forEach(r => {
    r.par.forEach((c, i) => drawCampoCompacto(doc, margin + i * (d.w + d.gap), state.y, d.w, r.h, c.label, c.linhas, c.acc));
    state.y += r.h + 3;
  });
  d.ex.forEach(c => { drawCampoCompacto(doc, margin, state.y, d.largura, c.h, c.label, c.linhas, c.acc); state.y += c.h + 3; });
  state.y += 2;
}
function drawCampoCompacto(doc, x, y, w, h, label, linhas, accent) {
  doc.setFillColor(...COR.fieldBg); doc.roundedRect(x, y, w, h, 4, 4, 'F');
  doc.setFillColor(...accent); doc.roundedRect(x, y, 4, h, 2, 2, 'F');
  doc.setFont('helvetica', 'bold'); doc.setFontSize(6.8); doc.setTextColor(...COR.muted);
  doc.text(String(label).toUpperCase(), x + 10, y + 10);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...COR.dark);
  linhas.forEach((ln, i) => doc.text(ln, x + 12, y + 25 + i * 12));
}

/* ===== RELATÓRIO GERENCIAL (dashboard) ===== */
function renderRelatorioPdf(doc, d, e, logo) {
  const st = novoEstado(e);
  const { W, margin } = st;
  const areaW = W - 2 * margin;
  const novaPagina = () => { doc.addPage(); doc.setFillColor(...COR.blue); doc.rect(0, 0, W, 36, 'F');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.setTextColor(...COR.white);
    doc.text(`${d.titulo || 'RELATÓRIO DE PRODUÇÃO'} (continuação)`, margin, 24); st.y = 54; };
  const garantir = (h) => { if (st.y + h > st.H - st.margin - RODAPE_RESERVA + 10) novaPagina(); };

  // Cabeçalho
  const H = 88;
  doc.setFillColor(...COR.blue); doc.rect(0, 0, W, H, 'F');
  doc.setFillColor(...COR.blueDark); doc.rect(0, H - 4, W, 4, 'F');
  let tx = margin;
  if (logo && logo.data) {
    const escala = Math.min(120 / logo.w, 56 / logo.h, 1), iw = logo.w * escala, ih = logo.h * escala;
    doc.setFillColor(...COR.white); doc.roundedRect(margin, 14, iw + 12, ih + 12, 5, 5, 'F');
    try { doc.addImage(logo.data, 'JPEG', margin + 6, 20, iw, ih); tx = margin + iw + 26; } catch (err) {}
  }
  doc.setFont('helvetica', 'bold'); doc.setFontSize(21); doc.setTextColor(...COR.white);
  doc.text(d.titulo || 'RELATÓRIO DE PRODUÇÃO', tx, 42);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(11); doc.setTextColor(...COR.tint);
  doc.text(`${e.nome || 'New Print Midia'}${d.subtitulo ? ' · ' + d.subtitulo : ''}`, tx, 60);
  st.y = H + 18;

  // KPIs: cartões, 4 por linha
  const kpis = d.kpis || [];
  const cols = 4, gap = 10, cw = (areaW - gap * (cols - 1)) / cols, ch = 64;
  for (let i = 0; i < kpis.length; i += cols) {
    garantir(ch + 10);
    kpis.slice(i, i + cols).forEach((k, c) => {
      const x = margin + c * (cw + gap), cor = COR[k.cor] || COR.blue;
      doc.setFillColor(...COR.fieldBg); doc.roundedRect(x, st.y, cw, ch, 6, 6, 'F');
      doc.setFillColor(...cor); doc.roundedRect(x, st.y, cw, 5, 2, 2, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(24); doc.setTextColor(...cor);
      doc.text(String(k.valor), x + cw / 2, st.y + 39, { align: 'center' });
      doc.setFontSize(8); doc.setTextColor(...COR.muted);
      doc.text(String(k.label).toUpperCase(), x + cw / 2, st.y + 55, { align: 'center' });
    });
    st.y += ch + 10;
  }
  st.y += 10;

  // Função genérica de tabela de triagem (atrasado / vai atrasar / aguardando produção)
  function tabelaTriagem(titulo, corBarra, colTitulo, linhas, vazio, corVazio) {
    garantir(90);
    drawSecao(doc, st, titulo, `${linhas.length} OS`);
    if (!linhas.length) {
      doc.setFillColor(...corVazio.bg); doc.roundedRect(margin, st.y, areaW, 34, 6, 6, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(...corVazio.fg);
      doc.text(vazio, margin + 14, st.y + 21);
      st.y += 46;
      return;
    }
    const col = { cli: 136, os: 48, un: 30, pz: 82, sit: 92 }; col.extra = areaW - col.cli - col.os - col.un - col.pz - col.sit;
    const cab = () => {
      doc.setFillColor(...COR.dark); doc.roundedRect(margin, st.y, areaW, 22, 4, 4, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(...COR.white);
      let x = margin + 8; const ty = st.y + 15;
      [['CLIENTE / PEDIDO', col.cli], ['OS', col.os], ['UN.', col.un], ['PRAZO', col.pz], ['STATUS', col.sit], [colTitulo, col.extra]].forEach(([t, w]) => { doc.text(t, x, ty); x += w; });
      st.y += 26;
    };
    garantir(60); cab();
    linhas.forEach((a, idx) => {
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10);
      const l1 = doc.splitTextToSize(String(a.cliente || 'Sem cliente'), col.cli - 12).slice(0, 2);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5);
      const l2 = doc.splitTextToSize(String(a.resumo || ''), col.cli - 12).slice(0, 2);
      const rh = Math.max(30, 10 + l1.length * 12 + l2.length * 10.5);
      if (st.y + rh > st.H - st.margin - RODAPE_RESERVA + 10) { novaPagina(); cab(); }
      doc.setFillColor(...(idx % 2 ? [250, 251, 253] : COR.fieldBg)); doc.roundedRect(margin, st.y, areaW, rh, 3, 3, 'F');
      doc.setFillColor(...corBarra); doc.rect(margin, st.y, 3, rh, 'F');
      let x = margin + 8;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...COR.dark);
      l1.forEach((ln, i) => doc.text(ln, x, st.y + 14 + i * 12));
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...COR.muted);
      l2.forEach((ln, i) => doc.text(ln, x, st.y + 14 + l1.length * 12 + i * 10.5 - 1));
      x += col.cli;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...COR.dark);
      doc.text(String(a.os || '—'), x, st.y + 14); x += col.os;
      doc.text(String(a.un), x, st.y + 14); x += col.un;
      doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.text(doc.splitTextToSize(String(a.prazo || '—'), col.pz - 6).slice(0,2), x, st.y + 14); x += col.pz;
      doc.setFontSize(9); doc.text(doc.splitTextToSize(String(a.status || ''), col.sit - 8).slice(0, 2), x, st.y + 14); x += col.sit;
      doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(...corBarra);
      doc.text(doc.splitTextToSize(String(a.extra || ''), col.extra - 6).slice(0, 2), x, st.y + 14);
      st.y += rh + 4;
    });
    st.y += 12;
  }

  tabelaTriagem('Atrasado agora', COR.red, 'ATRASO', d.atrasos || [], 'Nenhuma demanda atrasada no momento.', { bg: [232, 247, 239], fg: COR.green });
  tabelaTriagem('Vai atrasar nas próximas 48h', COR.orange, 'VENCE EM', d.vencendo || [], 'Nenhuma demanda vence nas próximas 48h.', { bg: [232, 247, 239], fg: COR.green });
  tabelaTriagem('Aguardando material / vai entrar em produção', COR.blue, 'PRAZO', d.aguardando || [], 'Nada aguardando material no momento.', { bg: COR.fieldBg, fg: COR.muted });

  // Gráficos de barra horizontais
  (d.grupos || []).forEach(g => {
    const linhas = (g.dados || []).slice(0, 12);
    if (!linhas.length) return;
    const rowH = 24;
    garantir(28 + Math.min(linhas.length, 3) * rowH);
    drawSecao(doc, st, g.titulo);
    const max = Math.max(...linhas.map(l => Number(l[1]) || 0), 1);
    const labW = 165, valW = 40, barW = areaW - labW - valW - 12;
    const cor = COR[g.cor] || COR.blue;
    linhas.forEach(([rot, val]) => {
      garantir(rowH + 4);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(10); doc.setTextColor(...COR.dark);
      doc.text(doc.splitTextToSize(String(rot), labW - 8)[0], margin, st.y + 14);
      doc.setFillColor(...COR.fieldBg); doc.roundedRect(margin + labW, st.y + 3, barW, 15, 3, 3, 'F');
      const w = Math.max(4, barW * (Number(val) || 0) / max);
      doc.setFillColor(...cor); doc.roundedRect(margin + labW, st.y + 3, w, 15, 3, 3, 'F');
      doc.setFont('helvetica', 'bold'); doc.setFontSize(11); doc.setTextColor(...COR.dark);
      doc.text(String(val), margin + areaW, st.y + 15, { align: 'right' });
      st.y += rowH;
    });
    st.y += 14;
  });
}

/* ===== Formatação / vocabulário (igual ao painel) ===== */
function enderecoPDF(p) {
  const e = p.endereco || {};
  if (!e.rua && !e.numero && !e.complemento && !e.bairro && !e.cidade && !e.cep && !e.referencia) {
    return p.retirada === 'Empresa vai até o cliente' ? 'Não informado' : '-';
  }
  const a = [];
  if (e.rua) a.push(e.rua + (e.numero ? `, ${e.numero}` : ''));
  if (e.complemento) a.push(e.complemento);
  if (e.bairro) a.push(e.bairro);
  if (e.cidade) a.push(e.cidade);
  if (e.cep) a.push(`CEP ${e.cep}`);
  if (e.referencia) a.push(`Ref.: ${e.referencia}`);
  return a.join(' · ');
}
function brPDF(x) { return x ? String(x).split('-').reverse().join('/') : '-'; }
function fmtPDF(x) { try { return new Date(x).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }); } catch (e) { return x; } }
function statusPDF(s) {
  return ({
    producao: 'EM PRODUÇÃO', impressao: 'NA IMPRESSÃO', acabamento: 'NO ACABAMENTO', corte: 'EM CORTE',
    laser: 'NO CORTE A LASER', costura: 'NA COSTURA', estamparia: 'NA ESTAMPARIA', calandra: 'NA CALANDRA',
    material: 'AGUARDANDO MATERIAL', pronto: 'PRONTO', entregue: 'ENTREGUE', cancelado: 'CANCELADO'
  })[s] || s || '';
}
function pagamentoResumoPDF(p) {
  const s = ({ nao_pago: 'NÃO PAGO', '50_pago': '50% PAGO', quitado: 'QUITADO', patrocinio: 'PATROCÍNIO DO DONO', personalizado: 'PAGAMENTO PERSONALIZADO' })[p.pagamentoStatus] || 'NÃO INFORMADO';
  const f = ({ pix: 'PIX', especie: 'ESPÉCIE', cartao: 'CARTÃO', especie_pix: 'ESPÉCIE + PIX', pix_pix: 'PIX + PIX', pix_cartao: 'PIX + CARTÃO', especie_cartao: 'ESPÉCIE + CARTÃO', patrocinio: 'PATROCÍNIO DO DONO', misto: 'OUTRO / MISTO' })[p.pagamentoForma] || '';
  const par = p.pagamentoParcelas > 1 ? ` · ${p.pagamentoParcelas}x` : '';
  return `${s}${f ? ` · ${f}` : ''}${par}`;
}
