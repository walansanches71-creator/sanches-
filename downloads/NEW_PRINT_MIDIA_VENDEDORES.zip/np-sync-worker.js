/* Runs on startup, alarms and local writes. No essential state lives in memory. */
importScripts('np-local.js','np-realtime.js');
(()=>{
 const base='https://producao-vip.pages.dev/pv-service/team';let running=false,again=false;
 async function api(path,credential,method='GET',body){let r;try{r=await fetch(base+path,{method,headers:{'content-type':'application/json','x-pv-session':credential.token},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(24000),cache:'no-store'})}catch{const e=Error('Offline — dados salvos localmente');e.offline=true;throw e}const data=await r.json();if(!r.ok){const e=Error(data.error||'Erro de sincronização');e.status=r.status;throw e}return data}
 async function state(data){await chrome.storage.local.set({npSyncState:{...data,at:Date.now()}})}
 async function notify(){await chrome.storage.local.set({npDataRevision:crypto.randomUUID()});}
 async function sync(){if(running){again=true;return}running=true;const start=Date.now();let credential;try{
  credential=(await chrome.storage.local.get('pvTeam')).pvTeam;if(!credential?.token)return;
  const me=await api('/me',credential);if(me.member.kind!=='seller')return;
  const saved=await NPStore.all();if(saved.pvLinkedMember&&saved.pvLinkedMember!==me.member.id)throw Error('Esta instalação pertence a outro vendedor.');
  await NPStore.transaction(s=>{s.pvLinkedMember=me.member.id;s.npSectors=me.sectors;NPStore.enqueue(s,{pedidos:s.pedidos||[],lixeira:s.lixeira||[],arquivados:s.arquivados||[]})});
  await state({auth:'ok',api:'ok',sync:'running',message:'Sincronizando…'});
  const outbox=(await NPStore.all()).pvOutbox||{};let firstError=null;
  for(const [id,q] of Object.entries(outbox)){
   if(Date.now()-start>18000){again=true;break}if(q.conflict)continue;
   try{let r;const b=(await NPStore.all()).pvSyncBase?.[id];
    if(q.action==='save'&&(b?.deleted||b?.archived)){
     const action=b.deleted?'restore':'unarchive';r=await api('/demands/'+encodeURIComponent(id)+'/'+action,credential,'POST',{expected_updated_at:q.expected,operation_id:q.uid+'-restore'});
     q.expected=r.demand.updated_at;await NPStore.transaction(s=>{if(s.pvOutbox?.[id]?.uid===q.uid)s.pvOutbox[id].expected=q.expected;s.pvSyncBase[id]={...s.pvSyncBase[id],deleted:false,archived:false,stamp:q.expected}});
    }
    if(q.action==='save'||!q.expected){r=await api('/demands',credential,'POST',{demand:q.demand,expected_updated_at:q.expected,operation_id:q.uid+(q.action==='save'?'':'-create')});if(q.action!=='save'){q.expected=r.demand.updated_at;await NPStore.transaction(s=>{if(s.pvOutbox?.[id]?.uid===q.uid)s.pvOutbox[id].expected=q.expected})}}
    if(q.action!=='save')r=await api('/demands/'+encodeURIComponent(id)+'/'+q.action,credential,'POST',{expected_updated_at:q.expected,operation_id:q.uid});
    await NPStore.transaction(s=>{const current=s.pvOutbox?.[id];if(current?.uid===q.uid){delete s.pvOutbox[id];NPStore.apply(s,r.demand,me.sectors)}else if(current){current.expected=r.demand.updated_at}else NPStore.apply(s,r.demand,me.sectors)});await notify();
   }catch(e){if(e.status===401)throw e;firstError=e;await NPStore.transaction(s=>{if(s.pvOutbox?.[id]?.uid===q.uid){s.pvOutbox[id].error=e.message;if(e.status===409)s.pvOutbox[id].conflict=true}});if(e.offline)throw e}
  }
  // Each page commits before the cursor. Repeating a page after interruption is safe.
  const local=await NPStore.all();let since=local.pvSyncCursor;if(!local.npLastFullSync||Date.now()-local.npLastFullSync>86400000||(since&&(!Number.isFinite(Date.parse(since))||Date.parse(since)>Date.now())))since=null;
  let page=local.npPull?.since===since?(local.npPull.page||{}):{},until;for(let i=0;i<1000;i++){const params=new URLSearchParams({...page,...(since?{since}:{})});const r=await api('/demands?'+params,credential);await NPStore.transaction(s=>{for(const row of r.demands||[])if(s.pvSyncBase?.[row.id]?.stamp!==row.updated_at)NPStore.apply(s,row,me.sectors)});until=r.until;if(!r.has_more){await NPStore.transaction(s=>{s.pvSyncCursor=until;s.npPull=null;if(!since)s.npLastFullSync=Date.now()});break}page={until,after:r.after,after_id:r.after_id};await NPStore.transaction(s=>{s.npPull={since,page}});if(Date.now()-start>20000){again=true;break}}
  await syncVisits(credential,start);
  const current=await NPStore.all(),pending=Object.keys(current.pvOutbox||{}).length+Object.keys(current.npVisitQueue||{}).length;
  await notify();await state({auth:'ok',api:'ok',sync:pending?'pending':'ok',pending,message:firstError?.message||(pending?pending+' alteração(ões) pendente(s).':'Tudo sincronizado às '+new Date().toLocaleTimeString('pt-BR'))});
 }catch(e){console.warn('[PV SYNC]',e.status||'network');await state({auth:e.status===401?'expired':'saved',api:'error',sync:'error',offline:!!e.offline,message:e.message});if(e.status===401){await chrome.storage.local.set({pvTeam:null});}}
 finally{running=false;if(again){again=false;setTimeout(sync,2000)}}}
 async function syncVisits(credential,start){const queue=(await NPStore.all()).npVisitQueue||{};for(const [id,q] of Object.entries(queue)){if(Date.now()-start>20000){again=true;break}if(q.conflict)continue;try{if(q.data.demand_id&&(await NPStore.all()).pvOutbox?.[q.data.demand_id])continue;const r=await api('/visits',credential,'POST',{...q.data,id,expected_updated_at:q.expected,operation_id:q.uid});await NPStore.transaction(s=>{const live=s.npVisitQueue?.[id];if(live?.uid===q.uid){delete s.npVisitQueue[id];s.npVisits={...s.npVisits,[id]:r.visit}}else if(live)live.expected=r.visit.updated_at});}catch(e){if(e.status===401||e.offline)throw e;await NPStore.transaction(s=>{if(s.npVisitQueue?.[id]?.uid===q.uid){s.npVisitQueue[id].error=e.message;s.npVisitQueue[id].conflict=e.status===409}})}}
  for(let offset=0;offset<100000;offset+=100){const r=await api('/visits?include_deleted=1&offset='+offset,credential);await NPStore.transaction(s=>{s.npVisits||={};for(const v of r.visits||[])if(!s.npVisitQueue?.[v.id])s.npVisits[v.id]=v});if((r.visits||[]).length<100)break}
 }
 const wake=()=>{chrome.alarms.create('np-sync',{periodInMinutes:1});sync()};chrome.runtime.onStartup.addListener(wake);chrome.runtime.onInstalled.addListener(wake);chrome.alarms.onAlarm.addListener(a=>{if(a.name==='np-sync')sync()});chrome.storage.onChanged.addListener((c,a)=>{if(a==='local'&&c.pvTeam?.newValue)sync()});chrome.runtime.onMessage.addListener((m,_sender,send)=>{if(m.type==='NP_SYNC'){sync().then(()=>send({ok:true}),()=>send({ok:false}));return true}});NPRealtime(()=>sync());wake();
})();
