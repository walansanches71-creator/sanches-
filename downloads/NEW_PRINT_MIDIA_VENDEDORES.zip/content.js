// Integração opcional com o WhatsApp Web para preparar/enviar a mensagem do pedido.
// Requer que o usuário esteja logado no WhatsApp Web.
(function(){
  let executando=false;
  let ultimoToken="";
  chrome.runtime.sendMessage({type:'WHATS_READY'}).catch(()=>{});
  chrome.runtime.onMessage.addListener(msg=>{
    if(msg.type==='WHATS_ENVIAR' && !executando && msg.token!==ultimoToken){ultimoToken=msg.token||`${Date.now()}`;executando=true; executar(msg).finally(()=>executando=false)}
  });
  async function executar(data){
    const ok=await esperar(()=>document.querySelector('div[contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab]'),30000);
    if(!ok){chrome.runtime.sendMessage({type:'WHATS_RESULT',ok:false,error:'Campo de mensagem não encontrado.'}).catch(()=>{});return}

    // Fluxo correto: 1) mensagem de aviso, 2) imagens.
    // Nunca colocamos a mensagem como legenda: ela deve chegar primeiro ao cliente.
    const texto=String(data.text||'').trim();
    if(texto){
      preencherTexto(texto);
      await dormir(500);
      const enviadoTexto=await esperarEnvio() || enviarEnter();
      if(!enviadoTexto){
        chrome.runtime.sendMessage({type:'WHATS_RESULT',ok:false,error:'Não foi possível enviar a mensagem de aviso.'}).catch(()=>{});
        return;
      }
      await dormir(900);
    }

    const imagens=Array.isArray(data.imageData)?data.imageData.filter(Boolean):(data.imageData?[data.imageData]:[]);
    for(const img of imagens){
      const attached=await anexarImagem(img);
      if(!attached){
        chrome.runtime.sendMessage({type:'WHATS_RESULT',ok:false,error:'Mensagem enviada, mas não foi possível anexar uma das imagens.'}).catch(()=>{});
        return;
      }
      await dormir(900);
      const enviado=await esperarEnvio();
      if(!enviado){
        chrome.runtime.sendMessage({type:'WHATS_RESULT',ok:false,error:'Mensagem enviada, mas o botão Enviar da imagem não foi encontrado.'}).catch(()=>{});
        return;
      }
      await dormir(1000);
    }

    chrome.runtime.sendMessage({type:'WHATS_RESULT',ok:true}).catch(()=>{});
  }
  function preencherTexto(text){
    const box=document.querySelector('div[contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab]');
    if(!box)return false;
    box.focus();
    const sel=window.getSelection();sel.removeAllRanges();const range=document.createRange();range.selectNodeContents(box);sel.addRange(range);document.execCommand('delete',false,null);document.execCommand('insertText',false,text);
    box.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));
    return true;
  }
  async function anexarImagem(dataUrl){
    try{
      const inputs=[...document.querySelectorAll('input[type="file"]')];
      const input=inputs.find(el=>{const a=(el.getAttribute('accept')||'').toLowerCase();return a.includes('image') && !a.includes('webp') && !a.includes('sticker')}) || inputs.find(el=>{const a=(el.getAttribute('accept')||'').toLowerCase();return a.includes('image')});
      if(!input)return false;
      const res=await fetch(dataUrl);const blob=await res.blob();
      const file=new File([blob],'pedido.jpg',{type:blob.type||'image/jpeg'});
      const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
      await dormir(2500);
      return true;
    }catch(e){return false}
  }

  async function esperarEnvio(){
    return await esperar(()=>{
      const b=encontrarEnviar();
      return !!(b && b.offsetParent!==null && !b.disabled);
    },10000) && !!clickEnviar();
  }
  function encontrarEnviar(){
    const candidates=[...document.querySelectorAll('button,[role="button"]')];
    return candidates.find(x=>{
      const a=(x.getAttribute('aria-label')||'').toLowerCase();
      const t=(x.getAttribute('title')||'').toLowerCase();
      const d=(x.getAttribute('data-testid')||'').toLowerCase();
      return a==='enviar'||a.includes('enviar')||t.includes('enviar')||d.includes('send');
    });
  }

  function clickEnviar(){const b=encontrarEnviar();if(b){b.click();return true}return false;}
  function enviarEnter(){const box=document.querySelector('div[contenteditable="true"][role="textbox"], div[contenteditable="true"][data-tab]');if(!box)return false;box.focus();box.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',code:'Enter',which:13,keyCode:13,bubbles:true}));return true}
  function esperar(fn,timeout){return new Promise(resolve=>{const start=Date.now();const t=setInterval(()=>{if(fn()){clearInterval(t);resolve(true)}else if(Date.now()-start>timeout){clearInterval(t);resolve(false)}},250)})}
  const dormir=ms=>new Promise(r=>setTimeout(r,ms));
})();
