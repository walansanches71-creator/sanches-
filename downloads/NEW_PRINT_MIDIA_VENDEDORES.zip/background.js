// New Print Midia — serviço de alertas em segundo plano
// O painel pode ser fechado: os pedidos continuam salvos e os alarmes continuam ativos
// enquanto o Chrome estiver aberto.

importScripts("voz.js");

const ALARM_PRAZOS = "producao-vip-verificar";
const ALARM_HORA = "producao-vip-hora";
const PREFIXO_HORA = "hora-pedido-";
const INTERVALO_REPETICAO_MS = 2 * 60 * 1000; // beep repetido de 2 em 2 minutos
const FINALIZADOS = ["pronto", "entregue", "cancelado"];

function garantirAlarmes() {
  // Varredura de segurança (1 em 1 min). O disparo no segundo exato é feito
  // pelos alarmes cravados por pedido, criados em agendarHorasMarcadas().
  chrome.alarms.create(ALARM_PRAZOS, { periodInMinutes: 1 });
  chrome.alarms.create(ALARM_HORA, { periodInMinutes: 1 });
}

// Próximo disparo exato: o instante do prazo; se já passou, o próximo múltiplo de 2 min.
function proximoDisparo(horaMs, agoraMs) {
  if (agoraMs < horaMs) return horaMs;
  const passos = Math.floor((agoraMs - horaMs) / INTERVALO_REPETICAO_MS) + 1;
  return horaMs + passos * INTERVALO_REPETICAO_MS;
}

async function agendarHorasMarcadas(agoraMs = Date.now()) {
  const { pedidos = [] } = await chrome.storage.local.get({ pedidos: [] });
  const ativos = new Set();

  for (const p of pedidos) {
    if (!p.horaMarcada || FINALIZADOS.includes(p.status)) continue;
    const t = new Date(p.horaMarcada).getTime();
    if (Number.isNaN(t)) continue;

    const nome = `${PREFIXO_HORA}${p.id}`;
    ativos.add(nome);

    const quando = proximoDisparo(t, agoraMs);
    const atual = await chrome.alarms.get(nome);
    // Só recria se o horário mudou (evita resetar o alarme a cada gravação).
    if (!atual || Math.abs((atual.scheduledTime || 0) - quando) > 1000) {
      chrome.alarms.create(nome, { when: quando });
    }
  }

  // Limpa alarmes de pedidos removidos ou já finalizados.
  const todos = await chrome.alarms.getAll();
  for (const a of todos) {
    if (a.name.startsWith(PREFIXO_HORA) && !ativos.has(a.name)) chrome.alarms.clear(a.name);
  }
}

chrome.runtime.onInstalled.addListener(() => {
  garantirAlarmes();
  agendarHorasMarcadas();
  verificarTudo();
});

// Limpa marcadores de "já falei" com mais de 7 dias, para não inchar o storage.
async function limparMarcadoresVoz() {
  const tudo = await chrome.storage.local.get(null);
  const limite = Date.now() - 7 * 86400000;
  const velhos = Object.keys(tudo).filter(
    (k) => k.startsWith("voz-dita-") && Number(tudo[k]) && Number(tudo[k]) < limite
  );
  if (velhos.length) await chrome.storage.local.remove(velhos);
}

chrome.runtime.onStartup.addListener(() => {
  limparMarcadoresVoz();
  // Recria os alarmes quando o Chrome inicia.
  garantirAlarmes();
  agendarHorasMarcadas();
  verificarTudo();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name.startsWith(PREFIXO_HORA)) {
    // Alarme cravado no segundo exato: avisa agora e já agenda o próximo (+2 min).
    await verificarTudo(Date.now());
    await agendarHorasMarcadas(Date.now() + 1000);
    return;
  }
  if (alarm.name === ALARM_PRAZOS || alarm.name === ALARM_HORA) {
    await verificarTudo();
    await agendarHorasMarcadas();
  }
});

// Se um pedido for salvo/alterado, verifica imediatamente, sem esperar o próximo minuto.
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.pedidos) { agendarHorasMarcadas(); verificarTudo(); }
});

chrome.action.onClicked.addListener(() => abrirPainel(true));

chrome.notifications.onClicked.addListener(() => abrirPainel(true));

async function abrirPainel(focar = true) {
  const url = chrome.runtime.getURL("painel.html");
  try {
    const janelas = await chrome.windows.getAll({ populate: true });
    for (const janela of janelas) {
      const aba = (janela.tabs || []).find(t => t.url === url);
      if (aba) {
        if (focar) await chrome.windows.update(janela.id, { focused: true });
        return janela.id;
      }
    }
    const janela = await chrome.windows.create({
      url,
      type: "popup",
      width: 610,
      height: 860,
      left: 80,
      top: 80,
      focused: true
    });
    return janela?.id;
  } catch (e) {
    console.warn("Não foi possível abrir o painel:", e);
  }
}

async function abrirModoTv() {
  const url = chrome.runtime.getURL("producao-tv.html");
  try {
    const janelas = await chrome.windows.getAll({ populate: true });
    for (const janela of janelas) {
      const aba = (janela.tabs || []).find(t => t.url === url);
      if (aba) {
        await chrome.windows.update(janela.id, { focused: true });
        return janela.id;
      }
    }
    const janela = await chrome.windows.create({
      url,
      type: "popup",
      width: 1280,
      height: 800,
      focused: true
    });
    return janela?.id;
  } catch (e) {
    console.warn("Não foi possível abrir o modo TV:", e);
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.alvo === "offscreen" || msg.type === "OFFSCREEN_PRONTO") return; // mensagens do player
  if (msg.type === "ABRIR_MODO_TV") {
    abrirModoTv();
    return;
  }
  if (msg.type === "CHECK_CLOCK_NOW") {
    verificarTudo(msg.now || Date.now()).catch(e => console.warn("Verificação exata:", e));
    return;
  }
  if (msg.type === "ENVIAR_WHATS") {
    prepararWhats(msg).catch(e => console.warn("WhatsApp:", e));
    return;
  }
  if (msg.type === "WHATS_READY") {
    chrome.storage.local.get({ whatsPendente: null }, async data => {
      const p = data.whatsPendente;
      if (!p || p.tabId !== sender.tab?.id) return;
      if (whatsTokenEmProcessamento === p.token) return;
      whatsTokenEmProcessamento = p.token;
      try {
        await chrome.tabs.sendMessage(sender.tab.id, { type: "WHATS_ENVIAR", text: p.text, imageData: p.imageData || "", token: p.token });
        const atual = await chrome.storage.local.get({ whatsPendente: null });
        if (atual.whatsPendente?.token === p.token) await chrome.storage.local.remove("whatsPendente");
      } catch (_) {}
      finally { whatsTokenEmProcessamento = null; }
    });
    return;
  }
  if (msg.type === "WHATS_RESULT") {
    chrome.storage.local.get({ whatsPendente: null }, data => {
      const p = data.whatsPendente;
      if (p && p.tabId === sender.tab?.id) chrome.storage.local.remove("whatsPendente");
    });
    return;
  }
  if (msg.type === "TESTAR_VOZ") {
    falar(msg.texto || "Teste de voz da New Print Midia. Pedido do cliente entrou na fila.", { fila: false })
      .then((ok) => sendResponse({ ok }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.type === "PARAR_VOZ") { pararFala(); return; }

  if (msg.type === "NOVA_DEMANDA") {
    configVoz().then((cfg) => notificar(
      "🆕 NOVA DEMANDA",
      `${msg.cliente} — ${msg.pedido}${msg.os ? ` · OS ${msg.os}` : ""} entrou na fila.`,
      true,
      "novo",
      cfg.falarNova
        ? limparParaVoz(`Nova demanda. Cliente ${msg.cliente}. Pedido ${msg.pedido}.${msg.os ? ` O S ${msg.os}.` : ""}${msg.prazo ? ` Prazo para ${dataFalada(msg.prazo)}.` : ""}`)
        : ""
    ));
  }

  if (msg.type === "STATUS_MUDOU") {
    // A voz só anuncia quando o pedido FICA PRONTO. As etapas intermediárias
    // (corte, costura, impressão etc.) continuam no aviso visual + beep,
    // mas sem fala — evita anúncio de voz a cada troca de setor.
    // O atraso é avisado por voz em outro lugar (verificarTudo), uma única vez.
    const ficouPronto = msg.status === "pronto";
    configVoz().then((cfg) => notificar(
      "🔄 STATUS ATUALIZADO",
      `${msg.cliente} — ${msg.pedido}: ${msg.statusNome}.`,
      false,
      "normal",
      (cfg.falarStatus && ficouPronto)
        ? limparParaVoz(`Atenção. Pedido de ${msg.cliente}, ${msg.pedido}, agora está ${artigoStatus(msg.statusNome)}.`)
        : ""
    ));
  }
  if (msg.type === "ENTRADA_PRODUCAO") {
    // Sem voz aqui: quem anuncia a etapa é o STATUS_MUDOU, senão falaria duas vezes.
    notificar(
      "🏭 ENTRADA NA PRODUÇÃO",
      `${msg.cliente} — ${msg.pedido} entrou na produção.${msg.tipo ? ` Tipo: ${msg.tipo}.` : ""}${msg.setores ? ` Setores: ${msg.setores}.` : ""}`,
      true,
      "novo"
    );
  }
  if (msg.type === "PRODUCAO_PRONTA") {
    // Sem voz aqui também: o STATUS_MUDOU já anuncia "agora está pronto".
    notificar(
      "🎉 Produção pronta!",
      `${msg.cliente} — ${msg.pedido} está pronto para retirada na loja.${msg.hora ? ` Hora combinada: ${msg.hora}.` : ""}`,
      true
    );
  }
  if (msg.type === "PAGAMENTO_PENDENTE") {
    configVoz().then((cfg) => notificar(
      "💜 PAGAMENTO PENDENTE",
      `${msg.cliente} — ${msg.pedido} está ${String(msg.statusNome || "").toLowerCase()}, mas o pagamento consta como ${msg.pagamento}.`,
      false,
      "normal",
      cfg.falarPagamento
        ? limparParaVoz(`Atenção. Pedido de ${msg.cliente}, ${msg.pedido}, está ${String(msg.statusNome || "").toLowerCase()}. Pagamento ainda ${msg.pagamento}.`)
        : ""
    ));
  }
  if (msg.type === "PRAZO_ALERTA") {
    notificar(
      msg.atrasado ? "🔴 Pedido atrasado" : "🟡 Prazo próximo",
      `${msg.cliente} — ${msg.pedido}. Prazo: ${msg.prazo}.`,
      !!msg.atrasado
    );
  }
  if (msg.type === "HORA_MARCADA_ALERTA") {
    notificar(
      "⏰ Hora marcada",
      `${msg.cliente} — atendimento/retirada agendado para ${msg.hora}.`,
      false
    );
  }
});

let whatsTokenEmProcessamento = null;

async function prepararWhats(msg) {
  const phone = String(msg.phone || "").replace(/\D/g, "");
  if (!phone) return;
  const url = `https://web.whatsapp.com/send?phone=${phone}`;
  const tabs = await chrome.tabs.query({ url: ["https://web.whatsapp.com/*"] });
  let tab;
  if (tabs && tabs.length) {
    tab = tabs[0];
    await chrome.tabs.update(tab.id, { url, active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    tab = await chrome.tabs.create({ url, active: true });
  }
  const token = `${Date.now()}-${Math.random()}`;
  await chrome.storage.local.set({ whatsPendente: { tabId: tab.id, text: msg.text || "", imageData: msg.imageData || "", createdAt: Date.now(), token } });
}

async function notificar(titulo, mensagem, deveAbrirPainel = false, som = "normal", fala = "") {
  const id = `${Date.now()}-${Math.random()}`;
  chrome.notifications.create(id, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title: titulo,
    message: mensagem,
    priority: 2,
    requireInteraction: !!deveAbrirPainel
  });
  // O som vem primeiro e é aguardado: só retorna depois que o player confirmou.
  await tocarAlerta(som);
  // Logo depois do bipe, a voz anuncia o aviso.
  if (fala) { try { await falar(fala); } catch (_) {} }
  if (deveAbrirPainel) await abrirPainel(true);
}

let criandoOffscreen = null;

async function garantirOffscreen() {
  const url = chrome.runtime.getURL("offscreen.html");
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
    documentUrls: [url]
  });
  if (contexts.length) return;

  // Trava: duas notificações simultâneas não podem criar o documento duas vezes.
  if (!criandoOffscreen) {
    criandoOffscreen = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["AUDIO_PLAYBACK"],
      justification: "Reproduzir alertas sonoros de pedidos e horários."
    }).catch((e) => {
      if (!String(e).includes("Only a single offscreen")) throw e;
    }).finally(() => { criandoOffscreen = null; });
  }
  await criandoOffscreen;
}

// Handshake: pergunta ao player se ele já está de pé antes de mandar tocar.
async function esperarPlayer(tentativas = 20) {
  for (let i = 0; i < tentativas; i++) {
    try {
      const r = await chrome.runtime.sendMessage({ alvo: "offscreen", type: "OFFSCREEN_PING" });
      if (r && r.pronto) return true;
    } catch (_) {}
    await new Promise((r) => setTimeout(r, 100));
  }
  return false;
}

async function tocarAlerta(som = "normal") {
  for (let tentativa = 0; tentativa < 2; tentativa++) {
    try {
      await garantirOffscreen();
      const pronto = await esperarPlayer();
      if (!pronto) continue;

      const resp = await chrome.runtime.sendMessage({ alvo: "offscreen", type: "TOCAR_ALERTA", som });
      if (resp && resp.ok) return true;
    } catch (e) {
      console.warn("Som de alerta — tentativa", tentativa + 1, e);
    }
    // Falhou: derruba o documento e tenta uma vez do zero.
    try { await chrome.offscreen.closeDocument(); } catch (_) {}
    await new Promise((r) => setTimeout(r, 200));
  }
  console.warn("Som de alerta indisponível após as tentativas.");
  return false;
}

// Evita duas verificações simultâneas (o painel pode pedir CHECK_CLOCK_NOW a cada segundo).
let verificacaoEmAndamento = false;

async function verificarTudo(agoraMs = Date.now()) {
  if (verificacaoEmAndamento) return;
  verificacaoEmAndamento = true;
  try {
    const { pedidos = [] } = await chrome.storage.local.get({ pedidos: [] });
    if (!pedidos.length) return;

    for (const p of pedidos) {
      const finalizado = FINALIZADOS.includes(p.status);
      if (finalizado) continue;

      // O atraso é tratado como UM único evento por demanda.
      // O beep repete a cada 2 minutos; a voz é independente e fala uma única vez,
      // a menos que "Repetir a fala do atraso" esteja habilitado.
      const limites = [];

      if (p.prazo) {
        const prazoFinal = new Date(`${p.prazo}T23:59:59`).getTime();
        if (!Number.isNaN(prazoFinal)) {
          limites.push({ tipo: "prazo", limite: prazoFinal, identificador: `prazo-${p.prazo}` });
        }
      }

      if (p.horaMarcada) {
        const hora = new Date(p.horaMarcada).getTime();
        if (!Number.isNaN(hora)) {
          limites.push({ tipo: "hora", limite: hora, identificador: `hora-${p.horaMarcada}` });
        }
      }

      for (const item of limites) {
        const diff = agoraMs - item.limite;

        if (diff >= 0) {
          const slot = Math.floor(diff / INTERVALO_REPETICAO_MS);
          const baseEvento = `${p.id}-${item.identificador}`;

          // BEep/notificação: continua repetindo de 2 em 2 minutos.
          const chaveBeep = `atraso-beep-v2-${baseEvento}-slot${slot}`;
          const marcado = await chrome.storage.local.get(chaveBeep);
          if (!marcado[chaveBeep]) {
            await chrome.storage.local.set({ [chaveBeep]: Date.now() });

            const mensagem = item.tipo === "hora"
              ? `${p.cliente} — o horário marcado (${fmtDataHora(p.horaMarcada)}) foi ultrapassado.`
              : `${p.cliente} — ${p.pedido}. O prazo de ${br(p.prazo)} foi ultrapassado.`;

            await notificar(
              item.tipo === "hora" && slot === 0 ? "🔴 ATRASO AGORA" : "🔴 PEDIDO ATRASADO",
              mensagem,
              true,
              "atrasado"
            );
          }

          // VOZ: uma única vez por DEMANDA/EVENTO, sem depender do minuto atual.
          // Se repetirAtraso estiver desligado, esta chave nunca muda.
          const cfgV = await configVoz();
          if (cfgV.falarAtraso) {
            const intervaloVoz = Math.max(5, Number(cfgV.minutosRepetir) || 30);
            const passoVoz = cfgV.repetirAtraso
              ? Math.floor((diff / 60000) / intervaloVoz)
              : 0;
            const chaveVoz = `atraso-voz-v2-${baseEvento}-${passoVoz}`;

            const texto = item.tipo === "hora"
              ? limparParaVoz(`Atenção! Demanda atrasada. Cliente ${p.cliente}, pedido ${p.pedido}. A hora marcada, ${horaFalada(p.horaMarcada)}, foi ultrapassada. Situação atual, ${nomeStatus(p.status)}.`)
              : limparParaVoz(`Atenção! Demanda atrasada. Cliente ${p.cliente}, pedido ${p.pedido}. O prazo de ${dataFalada(p.prazo)} foi ultrapassado. Situação atual, ${nomeStatus(p.status)}.`);

            await falarUmaVez(chaveVoz, texto, { fila: false });
          }
        } else if (item.tipo === "prazo") {
          // Prazo próximo: somente aviso/beep, nunca voz.
          const dias = Math.ceil((-diff) / 86400000);
          if (dias <= 1) {
            const agora = new Date(agoraMs);
            const hoje = agora.toLocaleDateString("en-CA");
            const chave = `proximo-${p.id}-${p.prazo}-${hoje}`;
            const jaAvisado = await chrome.storage.local.get(chave);
            if (!jaAvisado[chave]) {
              await chrome.storage.local.set({ [chave]: true });
              await notificar(
                "🟡 PRAZO PRÓXIMO",
                `${p.cliente} — ${p.pedido}. Prazo: ${br(p.prazo)}.`,
                false
              );
            }
          }
        }
      }
    }
  } finally {
    verificacaoEmAndamento = false;
  }
}

function br(x) {
  return String(x).split("-").reverse().join("/");
}

function fmtDataHora(x) {
  return new Date(x).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

const NOMES_STATUS = {
  producao: "EM PRODUÇÃO", impressao: "NA IMPRESSÃO", acabamento: "NO ACABAMENTO",
  corte: "EM CORTE", laser: "NO CORTE A LASER", costura: "NA COSTURA",
  estamparia: "NA ESTAMPARIA", calandra: "NA CALANDRA", material: "AGUARDANDO MATERIAL",
  pronto: "PRONTO", entregue: "ENTREGUE", cancelado: "CANCELADO"
};

function nomeStatus(chave) {
  return String(NOMES_STATUS[chave] || "EM PRODUÇÃO").toLowerCase();
}

// "NA COSTURA" -> "na costura" (a frase já traz o "está" antes)
function artigoStatus(nome) {
  return String(nome || "").toLowerCase();
}

importScripts("np-sync-worker.js");
