const $ = s => document.querySelector(s);

const STATUS = { producao:"EM PRODUÇÃO", impressao:"NA IMPRESSÃO", acabamento:"NO ACABAMENTO",
  corte:"EM CORTE", laser:"NO CORTE A LASER", costura:"NA COSTURA", estamparia:"NA ESTAMPARIA",
  calandra:"NA CALANDRA", material:"AGUARDANDO MATERIAL", pronto:"PRONTO", entregue:"ENTREGUE",
  cancelado:"CANCELADO" };

let pedidos = [];

// O painel principal usa IndexedDB desde a 2.17. O Modo TV precisa ler a mesma
// base; usar chrome.storage.local aqui fazia o TV enxergar uma base vazia/antiga.
const TVStorage = (() => {
  const DB_NAME = "producao-vip-db";
  const DB_VERSION = 2;
  const STORE = "kv";
  let db = null;

  function open(){
    return new Promise((resolve,reject)=>{
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        if(!d.objectStoreNames.contains(STORE)) d.createObjectStore(STORE);
        if(!d.objectStoreNames.contains("meta")) d.createObjectStore("meta");
      };
      req.onsuccess = () => { db=req.result; resolve(db); };
      req.onerror = () => reject(req.error);
    });
  }
  function all(){
    return new Promise((resolve,reject)=>{
      const tx=db.transaction(STORE,"readonly"), st=tx.objectStore(STORE), out={};
      const req=st.openCursor();
      req.onsuccess=()=>{ const c=req.result; if(!c){resolve(out);return;} out[c.key]=c.value; c.continue(); };
      req.onerror=()=>reject(req.error);
    });
  }
  async function get(){
    if(!db) await open();
    return all();
  }
  return {get};
})();

let tvCarregando = false;
let tvAtualizacao = null;

async function carregarDadosTV(){
  if(tvCarregando) return;
  tvCarregando = true;
  try{
    const x = await TVStorage.get();
    pedidos = Array.isArray(x.pedidos) ? x.pedidos : [];
    aplicarEmpresa(x.empresa || {});
    render();
  }catch(e){
    console.error("New Print Midia — Modo TV: erro ao ler IndexedDB", e);
  }finally{
    tvCarregando = false;
  }
}

function aplicarEmpresa(e) {
  const nome = (e && e.nome ? e.nome : "New Print Midia").trim() || "New Print Midia";
  $("#nomeEmpresa").textContent = nome;
  document.title = `${nome} — Modo TV`;
  if (e && e.logo) {
    $("#logoEmpresa").src = e.logo; $("#logoEmpresa").style.display = "block";
    $("#logoFallback").style.display = "none";
  } else {
    $("#logoEmpresa").removeAttribute("src"); $("#logoEmpresa").style.display = "none";
    $("#logoFallback").style.display = "block";
  }
}

// IndexedDB não dispara chrome.storage.onChanged. O TV relê a base periodicamente.
function verificarAtualizacaoTV(){ carregarDadosTV(); }

function finalizado(p) { return ["pronto", "entregue", "cancelado"].includes(p.status); }

function limitePedido(p) {
  const hm = p.horaMarcada ? new Date(p.horaMarcada) : null;
  if (hm && !Number.isNaN(hm.getTime())) return hm.getTime();
  if (p.prazo) {
    const d = new Date(p.prazo + "T23:59:59");
    if (!Number.isNaN(d.getTime())) return d.getTime();
  }
  return null;
}

function atrasado(p) { const l = limitePedido(p); return !finalizado(p) && l !== null && Date.now() >= l; }
function diasRestantes(p) { const l = limitePedido(p); return l === null ? null : Math.ceil((l - Date.now()) / 86400000); }
function proximo(p) { const d = diasRestantes(p); return !finalizado(p) && !atrasado(p) && d !== null && d <= 1; }

function contagem(ms) {
  ms = Math.max(0, ms);
  const dias = Math.floor(ms / 86400000); ms -= dias * 86400000;
  const horas = Math.floor(ms / 3600000); ms -= horas * 3600000;
  const minutos = Math.floor(ms / 60000); const segundos = Math.floor((ms % 60000) / 1000);
  const partes = [];
  if (dias) partes.push(`${dias}d`);
  partes.push(String(horas).padStart(2, "0"), String(minutos).padStart(2, "0"), String(segundos).padStart(2, "0"));
  return dias ? `${dias}d ${String(horas).padStart(2,"0")}:${String(minutos).padStart(2,"0")}:${String(segundos).padStart(2,"0")}`
              : `${String(horas).padStart(2,"0")}:${String(minutos).padStart(2,"0")}:${String(segundos).padStart(2,"0")}`;
}

function fmtDataHora(x) { return new Date(x).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }); }
function br(x) { return x ? String(x).split("-").reverse().join("/") : ""; }
function esc(x) { return String(x ?? "").replace(/[&<>"']/g, m => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;" }[m])); }

function itensTV(p) {
  if (Array.isArray(p.itens) && p.itens.length) return p.itens;
  if (p.pedido || p.tipoProduto || p.quantidade) return [{ tipo:p.tipoProduto||"", descricao:p.pedido||"", quantidade:Math.max(1,Number(p.quantidade)||1) }];
  return [];
}
function resumoTV(p) { return itensTV(p).map(x=>`${x.quantidade}x ${x.descricao||x.tipo||"item"}`).join(" · "); }

function cartaoHtml(p) {
  const a = atrasado(p), prox = proximo(p), l = limitePedido(p);
  let selo, selClasse, contHtml = "";

  if (p.status === "pronto") { selo = "PRONTO PARA RETIRADA"; selClasse = "selo-green"; }
  else if (a) { selo = `ATRASADO · ${STATUS[p.status] || ""}`; selClasse = "selo-red"; }
  else { selo = STATUS[p.status] || "EM PRODUÇÃO"; selClasse = "selo-blue"; }

  if (l !== null) {
    if (a) {
      contHtml = `<div class="contagem atraso">⏱ ATRASADO HÁ ${contagem(Date.now() - l)}</div>`;
    } else if (p.status !== "pronto") {
      const restante = l - Date.now();
      const classe = prox ? "proximo" : "normal";
      contHtml = `<div class="contagem ${classe}">⏳ faltam ${contagem(restante)}</div>`;
    }
  }

  const hora = p.horaMarcada ? `<div class="hora-marcada">⏰ Hora marcada: ${fmtDataHora(p.horaMarcada)}</div>` : "";
  const prazoLinha = !p.horaMarcada && p.prazo ? `<div class="hora-marcada">📅 Prazo: ${br(p.prazo)}</div>` : "";

  const imgs = Array.isArray(p.imagensPedido) && p.imagensPedido.length ? p.imagensPedido : (p.imagemPedido ? [p.imagemPedido] : []);
  let foto = "";
  if (imgs.length) {
    // Gira sozinho entre as fotos (troca a cada 4s), sem precisar de temporizador próprio:
    // o índice é calculado a partir do relógio, então sobrevive à re-renderização a cada segundo.
    const indice = imgs.length > 1 ? Math.floor(Date.now() / 4000) % imgs.length : 0;
    const pontos = imgs.length > 1
      ? `<div class="cartao-foto-pontos">${imgs.map((_, i) => `<span class="${i === indice ? "ativo" : ""}"></span>`).join("")}</div>`
      : "";
    const contadorFoto = imgs.length > 1 ? `<span class="cartao-foto-qtd">${indice + 1}/${imgs.length}</span>` : "";
    foto = `<div class="cartao-foto"><img src="${imgs[indice]}" alt="Referência do pedido ${indice + 1} de ${imgs.length}">${contadorFoto}${pontos}</div>`;
  }

  return `<article class="cartao ${a ? "cartao-atrasado" : ""} ${foto ? "com-foto" : ""}">
    ${foto}
    <div class="cartao-corpo">
      <div class="topo">
        <div><div class="cliente">${esc(p.cliente)}</div><div class="info">${esc(p.pedido || resumoTV(p))} · ${itensTV(p).reduce((n,x)=>n+(Number(x.quantidade)||0),0) || p.quantidade || 1} un.${p.os ? ` · OS ${esc(p.os)}` : ""}</div>
        <div class="itens-tv">${itensTV(p).map(x=>`<span>${esc(x.descricao||x.tipo||"Item")} <b>${Number(x.quantidade)||1}x</b></span>`).join("")}</div></div>
        <span class="selo ${selClasse}">${selo}</span>
      </div>
      ${contHtml}${hora}${prazoLinha}
    </div>
  </article>`;
}

function render() {
  const abertos = pedidos.filter(p => !finalizado(p));
  const prontos = pedidos.filter(p => p.status === "pronto");
  const emAndamento = abertos.filter(p => p.status !== "pronto");

  $("#qtdAtrasado").textContent = emAndamento.filter(atrasado).length;
  $("#qtdProximo").textContent = emAndamento.filter(proximo).length;
  $("#qtdProducao").textContent = emAndamento.filter(p => !atrasado(p) && !proximo(p)).length;
  $("#qtdPronto").textContent = prontos.length;

  const ordenados = [...emAndamento].sort((x, y) => {
    const rank = p => atrasado(p) ? 0 : proximo(p) ? 1 : 2;
    const rx = rank(x), ry = rank(y);
    if (rx !== ry) return rx - ry;
    const lx = limitePedido(x) ?? Infinity, ly = limitePedido(y) ?? Infinity;
    return lx - ly;
  });
  const lista = [...ordenados, ...prontos.sort((x, y) => (Number(x.criado)||0) - (Number(y.criado)||0))];

  const quadro = $("#quadro"), vazio = $("#vazio");
  if (!lista.length) {
    quadro.innerHTML = "";
    vazio.classList.remove("oculto");
    return;
  }
  vazio.classList.add("oculto");
  quadro.innerHTML = lista.map(cartaoHtml).join("");
}

function atualizarRelogio() {
  const agora = new Date();
  $("#hora").textContent = agora.toLocaleTimeString("pt-BR", { hour12: false });
  $("#data").textContent = agora.toLocaleDateString("pt-BR");
}

carregarDadosTV();
atualizarRelogio();
// Relê os dados do IndexedDB a cada 2 segundos para refletir alterações do painel.
setInterval(() => { atualizarRelogio(); verificarAtualizacaoTV(); }, 2000);
