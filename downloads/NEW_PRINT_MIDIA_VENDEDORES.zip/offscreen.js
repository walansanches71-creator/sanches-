/* New Print Midia — player de áudio (documento offscreen)
   Handshake: o background só dispara o som depois deste documento confirmar
   que carregou e que o arquivo de áudio está pronto para tocar. */

const MAPA_SONS = { novo: "somNovo", atrasado: "somAtrasado", normal: "som" };

function esperarCarregar(audio) {
  // readyState >= 3 (HAVE_FUTURE_DATA) já garante início imediato do play()
  if (audio.readyState >= 3) return Promise.resolve();
  return new Promise((resolve) => {
    let feito = false;
    const ok = () => { if (!feito) { feito = true; limpar(); resolve(); } };
    const limpar = () => {
      audio.removeEventListener("canplaythrough", ok);
      audio.removeEventListener("loadeddata", ok);
      audio.removeEventListener("error", ok);
      clearTimeout(timer);
    };
    const timer = setTimeout(ok, 3000); // nunca trava o alerta
    audio.addEventListener("canplaythrough", ok);
    audio.addEventListener("loadeddata", ok);
    audio.addEventListener("error", ok);
    try { audio.load(); } catch (_) {}
  });
}

async function tocar(som) {
  const id = MAPA_SONS[som] || "som";
  const a = document.getElementById(id) || document.getElementById("som");
  if (!a) return false;
  document.querySelectorAll("audio").forEach((x) => {
    if (x !== a) { try { x.pause(); x.currentTime = 0; } catch (_) {} }
  });
  await esperarCarregar(a);
  try {
    a.pause();
    a.currentTime = 0;
    a.volume = 1;
    await a.play();
    return true;
  } catch (_) {
    // segunda tentativa curta (o player pode ter acabado de acordar)
    await new Promise((r) => setTimeout(r, 150));
    try { a.currentTime = 0; await a.play(); return true; } catch (_) { return false; }
  }
}

/* ---------- Plano B da voz: speechSynthesis ---------- */

function vozesDisponiveis() {
  const v = speechSynthesis.getVoices();
  if (v && v.length) return Promise.resolve(v);
  return new Promise((resolve) => {
    let feito = false;
    const ok = () => { if (!feito) { feito = true; resolve(speechSynthesis.getVoices() || []); } };
    speechSynthesis.addEventListener("voiceschanged", ok, { once: true });
    setTimeout(ok, 800);
  });
}

const PREF_MASC = ["daniel", "antonio", "antônio", "ricardo", "felipe", "male", "homem"];

async function dizer(msg) {
  try {
    if (!msg.fila) { try { speechSynthesis.cancel(); } catch (_) {} }
    const vozes = await vozesDisponiveis();
    const fala = new SpeechSynthesisUtterance(String(msg.texto || ""));
    fala.lang = "pt-BR";
    fala.rate = Number(msg.taxa) || 1;
    fala.pitch = Number(msg.tom) || 1;
    fala.volume = Number(msg.volume) || 1;

    let escolhida = msg.voz ? vozes.find((v) => v.name === msg.voz) : null;
    if (!escolhida) {
      const pt = vozes.filter((v) => /^pt[-_]?BR/i.test(v.lang || "")).concat(
        vozes.filter((v) => /^pt/i.test(v.lang || ""))
      );
      escolhida =
        pt.find((v) => PREF_MASC.some((n) => v.name.toLowerCase().includes(n))) || pt[0];
    }
    if (escolhida) fala.voice = escolhida;

    speechSynthesis.speak(fala);
    return true;
  } catch (_) { return false; }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.alvo !== "offscreen") return;

  if (msg.type === "OFFSCREEN_PING") { sendResponse({ pronto: true }); return; }

  if (msg.type === "FALAR") {
    dizer(msg).then((ok) => sendResponse({ ok })).catch(() => sendResponse({ ok: false }));
    return true;
  }

  if (msg.type === "PARAR_FALA") {
    try { speechSynthesis.cancel(); } catch (_) {}
    sendResponse({ ok: true });
    return;
  }

  if (msg.type === "TOCAR_ALERTA") {
    tocar(msg.som).then((ok) => sendResponse({ ok })).catch(() => sendResponse({ ok: false }));
    return true; // resposta assíncrona
  }
});

// Avisa o background assim que o documento estiver de pé.
try { chrome.runtime.sendMessage({ type: "OFFSCREEN_PRONTO" }); } catch (_) {}
