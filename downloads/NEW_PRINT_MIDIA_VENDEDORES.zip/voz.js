/* New Print Midia — módulo de voz (TTS)
   Fala os avisos em português usando chrome.tts (vozes do sistema/Google).
   Se o chrome.tts não estiver disponível, cai para o speechSynthesis do
   documento offscreen — o mesmo que já toca os sons de alerta. */

const VOZ_PADRAO = {
  ativa: true,
  voz: "",          // "" = automática (prefere voz masculina pt-BR)
  taxa: 1.0,        // velocidade  (0.5 a 2.0)
  tom: 0.9,         // tom da voz  (0.0 a 2.0) — 0.9 deixa mais grave/masculina
  volume: 1.0,
  falarNova: true,      // nova demanda / demanda pega
  falarStatus: true,    // mudança de status (ex.: na costura)
  falarPronto: true,    // produção pronta
  falarAtraso: true,    // atraso de prazo ou hora marcada
  repetirAtraso: false, // repetir a fala do atraso de tempos em tempos
  minutosRepetir: 30    // se repetirAtraso estiver ligado, a cada X minutos
};

// Ordem de preferência para escolher sozinho uma voz masculina em pt-BR.
const PREFERIDAS_MASC = ["daniel", "antonio", "antônio", "ricardo", "felipe", "male", "homem"];

async function configVoz() {
  const { vozConfig = {} } = await chrome.storage.local.get({ vozConfig: {} });
  return { ...VOZ_PADRAO, ...vozConfig };
}

function listarVozes() {
  return new Promise((resolve) => {
    try {
      if (!chrome.tts || !chrome.tts.getVoices) return resolve([]);
      chrome.tts.getVoices((vozes) => resolve(vozes || []));
    } catch (_) { resolve([]); }
  });
}

/* Escolhe a melhor voz: a salva pelo usuário; senão uma masculina pt-BR;
   senão qualquer pt-BR; senão qualquer português. */
async function escolherVoz(nomeSalvo) {
  const vozes = await listarVozes();
  if (!vozes.length) return null;

  if (nomeSalvo) {
    const exata = vozes.find((v) => v.voiceName === nomeSalvo);
    if (exata) return exata;
  }

  const ptBr = vozes.filter((v) => /^pt[-_]?BR/i.test(v.lang || ""));
  const pt = vozes.filter((v) => /^pt/i.test(v.lang || ""));
  const pool = ptBr.length ? ptBr : pt;
  if (!pool.length) return null;

  const masc = pool.find(
    (v) =>
      String(v.gender || "").toLowerCase() === "male" ||
      PREFERIDAS_MASC.some((n) => String(v.voiceName || "").toLowerCase().includes(n))
  );
  return masc || pool[0];
}

let falandoAgora = false;
let ultimaFala = { texto: "", quando: 0 };

/* Fala só uma vez por chave: o bipe e a notificação continuam repetindo,
   mas a voz não entra em loop. */
async function falarUmaVez(chave, texto, { fila = false } = {}) {
  const k = `voz-dita-${chave}`;
  const ja = await chrome.storage.local.get(k);
  if (ja[k]) return false;
  await chrome.storage.local.set({ [k]: Date.now() });
  return falar(texto, { fila });
}

/* Fala um texto. fila = true enfileira em vez de cortar o aviso anterior. */
async function falar(texto, { fila = true } = {}) {
  const t = String(texto || "").trim();
  if (!t) return false;

  const cfg = await configVoz();
  if (!cfg.ativa) return false;

  // Trava anti-repetição: o mesmo aviso não é falado duas vezes em 15 s.
  const agora = Date.now();
  if (t === ultimaFala.texto && agora - ultimaFala.quando < 15000) return false;
  ultimaFala = { texto: t, quando: agora };

  const voz = await escolherVoz(cfg.voz);

  const opcoes = {
    lang: "pt-BR",
    rate: Number(cfg.taxa) || 1,
    pitch: Number(cfg.tom) || 1,
    volume: Number(cfg.volume) || 1,
    enqueue: !!fila
  };
  if (voz && voz.voiceName) opcoes.voiceName = voz.voiceName;

  const okTts = await new Promise((resolve) => {
    try {
      if (!chrome.tts || !chrome.tts.speak) return resolve(false);
      let respondeu = false;
      const encerrar = (v) => { if (!respondeu) { respondeu = true; resolve(v); } };
      opcoes.onEvent = (ev) => {
        if (ev.type === "start") falandoAgora = true;
        if (ev.type === "end" || ev.type === "interrupted" || ev.type === "cancelled") falandoAgora = false;
        // Um erro REAL do motor (voz não encontrada, engine indisponível etc.)
        // é o único caso em que vale cair pro plano B.
        if (ev.type === "error") { falandoAgora = false; encerrar(false); }
      };
      chrome.tts.speak(t, opcoes, () => {
        // O callback do speak() volta na hora, ANTES da fala começar — ele só
        // confirma que o pedido foi aceito (documentação oficial do chrome.tts).
        // Não é sinal de falha o fato de ainda estar esperando a vez na fila,
        // então aqui já damos como certo, sem esperar o evento "start".
        if (chrome.runtime.lastError) encerrar(false);
        else encerrar(true);
      });
      // Rede de segurança apenas para o caso do motor travar de verdade e nem
      // o callback do speak() responder (raro). Com folga suficiente pra não
      // confundir "esperando na fila" com "falhou".
      setTimeout(() => encerrar(false), 5000);
    } catch (_) { resolve(false); }
  });

  if (okTts) return true;
  return falarNoOffscreen(t, cfg, voz && voz.voiceName, fila);
}

/* Plano B: speechSynthesis dentro do documento offscreen. */
async function falarNoOffscreen(texto, cfg, nomeVoz, fila = true) {
  try {
    await garantirOffscreen();
    await esperarPlayer();
    const r = await chrome.runtime.sendMessage({
      alvo: "offscreen",
      type: "FALAR",
      texto,
      voz: nomeVoz || cfg.voz || "",
      taxa: Number(cfg.taxa) || 1,
      tom: Number(cfg.tom) || 1,
      volume: Number(cfg.volume) || 1,
      fila: !!fila
    });
    return !!(r && r.ok);
  } catch (e) {
    console.warn("Voz indisponível:", e);
    return false;
  }
}

function pararFala() {
  try { chrome.tts && chrome.tts.stop && chrome.tts.stop(); } catch (_) {}
  try { chrome.runtime.sendMessage({ alvo: "offscreen", type: "PARAR_FALA" }); } catch (_) {}
  falandoAgora = false;
}

/* ---------- Texto falado ---------- */

const MESES = ["janeiro","fevereiro","março","abril","maio","junho","julho",
               "agosto","setembro","outubro","novembro","dezembro"];

// "2026-09-17" -> "17 de setembro"
function dataFalada(iso) {
  const m = String(iso || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!m) return "";
  return `${Number(m[3])} de ${MESES[Number(m[2]) - 1] || ""}`;
}

// "2026-09-17T14:30" -> "17 de setembro às 14 e 30"
function horaFalada(valor) {
  const d = new Date(valor);
  if (Number.isNaN(d.getTime())) return "";
  const min = d.getMinutes();
  const hora = min === 0 ? `${d.getHours()} horas` : `${d.getHours()} e ${min}`;
  return `${d.getDate()} de ${MESES[d.getMonth()]} às ${hora}`;
}

// Tira emojis, asteriscos e cortes que a voz lê errado.
function limparParaVoz(txt) {
  return String(txt || "")
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, " ")
    .replace(/[*_`#]/g, " ")
    .replace(/\s*[—–\-·]\s*/g, ", ")
    .replace(/\s{2,}/g, " ")
    .trim();
}
