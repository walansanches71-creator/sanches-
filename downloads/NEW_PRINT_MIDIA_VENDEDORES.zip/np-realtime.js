/* Realtime is an accelerator; API alarms remain the delivery guarantee. */
(()=>{globalThis.NPRealtime=function(onChange,onStatus=()=>{}){
 const endpoint='wss://ugqxcarzyjmybyrpdrqx.supabase.co/realtime/v1/websocket?apikey=sb_publishable_sgOPJAIJdYl3PPBPh_zIwA_MSss6Scj&vsn=1.0.0';let socket,timer,heartbeat,closed=false,attempt=0,ref=0,pending,lastReply=0,joined=false;const delays=[1000,2000,5000,10000,30000];
 const notify=k=>{clearTimeout(pending);pending=setTimeout(()=>onChange(k||'all'),200)};
 function connect(){if(closed)return;joined=false;onStatus('Reconectando…');const ws=socket=new WebSocket(endpoint);lastReply=Date.now();
 ws.onopen=()=>{if(ws!==socket)return;ws.send(JSON.stringify({topic:'realtime:pv-production',event:'phx_join',payload:{config:{broadcast:{ack:false,self:false},presence:{enabled:false},private:false}},ref:'join',join_ref:'join'}));heartbeat=setInterval(()=>{if(Date.now()-lastReply>45000||(!joined&&Date.now()-lastReply>20000)){ws.close();return}if(ws.readyState===1)ws.send(JSON.stringify({topic:'phoenix',event:'heartbeat',payload:{},ref:String(++ref)}))},15000)};
 ws.onmessage=e=>{if(ws!==socket)return;try{const m=JSON.parse(e.data);lastReply=Date.now();if(m.event==='phx_reply'&&m.ref==='join'){if(m.payload.status==='ok'){joined=true;attempt=0;onStatus('Ao vivo');notify('all')}else ws.close()}if(m.event==='broadcast'&&m.payload?.event==='changed')notify(m.payload.payload?.kind||'all');if(['phx_error','phx_close'].includes(m.event))ws.close()}catch{}};
 ws.onerror=()=>ws.close();ws.onclose=()=>{clearInterval(heartbeat);if(closed)return;joined=false;onStatus('Reconectando…');clearTimeout(timer);timer=setTimeout(connect,delays[Math.min(attempt++,delays.length-1)])};
 }
 const online=()=>{notify('all');if(!joined){clearTimeout(timer);if(socket&&socket.readyState<2)socket.close();else connect()}};globalThis.addEventListener?.('online',online);const fallback=setInterval(()=>notify('all'),30000);connect();return ()=>{closed=true;clearTimeout(timer);clearTimeout(pending);clearInterval(heartbeat);clearInterval(fallback);socket?.close();globalThis.removeEventListener?.('online',online)};
}})();
